# Official cvelistV5 source-evidence note

## Scope and evidence-gate conclusion

This note records the official-source basis for reconstructing historical CVE `PUBLISHED` state in the locked 749-event study cohort. It does not change any locked EPSS, KEV, Top-K, cadence, transport, or model result.

**Evidence-gate conclusion: proceed with Tier-A Git/release reconstruction.** The official cvelistV5 Git history can identify the first historical state in which an exact CVE record is present with `cveMetadata.state = PUBLISHED`. Adjacent hourly tags and release assets can corroborate that state. Current `datePublished` metadata remains a cross-check rather than the primary historical observation.

For the documented MITRE CNA-LR problem window, a record may be admitted as `KEEP` only when historical Git/release evidence independently resolves its official cvelistV5 `PUBLISHED` state. Otherwise it must remain `HOLD`.

## Pinned official provenance

| Item | Pinned evidence |
|---|---|
| Official repository | [CVEProject/cvelistV5](https://github.com/CVEProject/cvelistV5) |
| Pinned `main` commit | [`4bc05add0932bd642880fc7a46dfb589889217eb`](https://github.com/CVEProject/cvelistV5/commit/4bc05add0932bd642880fc7a46dfb589889217eb) |
| Pinned commit time | `2026-09-20T20:15:53Z` |
| Pinned tree | `1a3fc4678e1a0f0d6c5eddf53090f1a937d7047f` |
| Immutable README | [README at the pinned commit](https://github.com/CVEProject/cvelistV5/blob/4bc05add0932bd642880fc7a46dfb589889217eb/README.md) |
| README bytes | `12,205` canonical raw bytes |
| README SHA-256 | `b286ee977a28db6a623a6389f7d61a7167f3b6fc8d14967418a7500714c6fbd7` |

The pinned README identifies cvelistV5 as the official CVE List, states that repository content is refreshed from the official CVE Services API approximately every seven minutes, and documents both Git and release-based acquisition.

### Official release model

The [pinned release documentation](https://github.com/CVEProject/cvelistV5/blob/4bc05add0932bd642880fc7a46dfb589889217eb/README.md#releases) specifies:

- a daily baseline issued at midnight UTC, conventionally named `YYYY-MM-DD_all_CVEs_at_midnight.zip`;
- hourly delta releases, conventionally named `YYYY-MM-DD_delta_CVEs_at_HH00Z.zip`;
- hourly deltas that contain changes since the daily baseline rather than an independently complete list.

Consequently, absence from an hourly delta alone is not evidence that a CVE was absent from the official list. A valid absence finding must use the exact tagged Git tree or a reconstructed baseline-plus-delta state. Release names are conventions, not identifiers: exact tag, commit, release ID, asset ID, size, URL, and locally calculated SHA-256 should be retained.

## Official MITRE CNA-LR known issue

The current pinned README continues to warn that publication and update date discrepancies affect approximately 515 records published by the MITRE CNA-LR from **2024-05-08 through 2024-06-07**. The warning was introduced in official README commit [`4aef1e881be7da4496d01bf2420df6d5540fcfa3`](https://github.com/CVEProject/cvelistV5/commit/4aef1e881be7da4496d01bf2420df6d5540fcfa3).

The warning is specifically material to date-sensitive metrics. It means that a current record's `datePublished` or `dateUpdated` must not, by itself, establish historical `PUBLISHED` state in this interval. It does not make the immutable historical repository state unusable: an exact earlier tree, first `PUBLISHED` commit, parent tree, and official release can independently resolve whether the record was present in that state in the admitted official source.

A scan of all 749 locked cohort identifiers at the pinned current tree found one record matching both `assignerShortName = mitre` and a current `datePublished` inside the inclusive warned interval: **CVE-2024-37383**. This record is therefore the cohort-specific test of the known-issue gate.

## CVE-2024-37383: independent historical resolution

### Current metadata is not sufficient

At the pinned current tree, [CVE-2024-37383](https://github.com/CVEProject/cvelistV5/blob/4bc05add0932bd642880fc7a46dfb589889217eb/cves/2024/37xxx/CVE-2024-37383.json) is `PUBLISHED`, has `assignerShortName = mitre`, and reports `datePublished = 2024-06-07T00:00:00.000Z`. Its canonical raw bytes at the pinned commit are:

- byte count: `9,489`;
- SHA-256: `55cc1c88a0a8e976a3c26c7be07a831682ab8684a3ee2e9b8ac8965b480a5379`.

That current midnight timestamp is not used as primary evidence because the record falls inside the official warning interval.

### First exact `PUBLISHED` state

The file first appears as an added, `PUBLISHED` record in official commit [`868e1135389199d066f8b1cc6e8009c56084e678`](https://github.com/CVEProject/cvelistV5/commit/868e1135389199d066f8b1cc6e8009c56084e678), whose Git author and committer time is `2024-06-07T03:30:57Z`.

Exact identifiers:

| Field | Value |
|---|---|
| First `PUBLISHED` commit | `868e1135389199d066f8b1cc6e8009c56084e678` |
| Commit time | `2024-06-07T03:30:57Z` |
| Parent commit | `eaee6a5149be983fbde18e39200de5cdb67d5e0c` |
| Commit tree | `5021fc9b8e8a326f0ca6beda3554fcedbc3f037c` |
| Git blob SHA-1 | `6c827d7646508a1c4b35a324fb5d1e9d81eb792f` |
| Historical JSON path | `cves/2024/37xxx/CVE-2024-37383.json` |
| Historical JSON bytes | `1,948` |
| Historical JSON SHA-256 | `dd95adb955fe0a17ef364da726850c138ab6b940b9704762c3171e08cbcdaedc` |

The exact [historical JSON blob](https://github.com/CVEProject/cvelistV5/blob/868e1135389199d066f8b1cc6e8009c56084e678/cves/2024/37xxx/CVE-2024-37383.json) is `PUBLISHED` but contains **no `datePublished` field**; it contains `dateUpdated = 2024-06-07T03:24:38.347316`. This directly demonstrates why the later current metadata value cannot substitute for historical-state evidence.

The parent commit is also the `cve_2024-06-07_0300Z` tag target and lacks the file. The addition commit therefore establishes a transition from absent to present-as-`PUBLISHED` in the official Git history.

### Hourly release corroboration

The adjacent official releases independently bracket the transition:

| Evidence | 0300Z state | 0400Z state |
|---|---|---|
| Release | [`cve_2024-06-07_0300Z`](https://github.com/CVEProject/cvelistV5/releases/tag/cve_2024-06-07_0300Z) | [`cve_2024-06-07_0400Z`](https://github.com/CVEProject/cvelistV5/releases/tag/cve_2024-06-07_0400Z) |
| Tag target | `eaee6a5149be983fbde18e39200de5cdb67d5e0c` | `de34a5f6ada69a8da681600a12392e1cd3b0668b` |
| Git tree result | target path absent | target path present as `PUBLISHED` |
| GitHub release ID | `159296990` | `159303497` |
| Release published at | `2024-06-07T03:06:12Z` | `2024-06-07T04:06:51Z` |
| Delta asset ID | `172402421` | `172409619` |
| Delta asset bytes | `7,674` | `16,655` |
| Delta asset SHA-256 | `9499b2e41ccdfa30daa2f01cf35aba7518fa38f53a3e891d4ec7f3da66811878` | `881fb25c3d61e6c7bd5dda98d0b332bc382e7e977993e40a7005d4d4b61886f5` |
| CVE entry in delta | absent | present |

The [0400Z delta asset](https://github.com/CVEProject/cvelistV5/releases/download/cve_2024-06-07_0400Z/2024-06-07_delta_CVEs_at_0400Z.zip) contains `deltaCves/CVE-2024-37383.json`. That entry is byte-for-byte identical to the first Git blob: 1,948 bytes and SHA-256 `dd95adb955fe0a17ef364da726850c138ab6b940b9704762c3171e08cbcdaedc`. The [0300Z delta asset](https://github.com/CVEProject/cvelistV5/releases/download/cve_2024-06-07_0300Z/2024-06-07_delta_CVEs_at_0300Z.zip) does not contain it, and the exact 0300Z tagged tree also lacks it.

GitHub's release API reports no stored digest for these older assets (`digest = null`), so the SHA-256 values above were calculated from the downloaded asset bytes. Asset IDs, sizes, immutable URLs, and hashes should all be preserved in the acquisition log.

### Admission decision for this record

For official cvelistV5 `PUBLISHED` state, CVE-2024-37383 can be classified:

- `known_issue_window = true`;
- `metadata_discrepancy = true`;
- `publication_evidence_status = KEEP`;
- primary evidence type: first exact Git `PUBLISHED` state, corroborated by the next official hourly release;
- earliest defensible observed historical `PUBLISHED`-state date: `2024-06-07`;
- repository-history timestamp: `2024-06-07T03:30:57Z`;
- conservative independently published release upper bound: `2024-06-07T04:06:51Z`.

The record's locked KEV admission date is `2024-10-24`, and it is already in the locked EPSS-observable set. Its official `PUBLISHED`-state evidence therefore precedes the later decision opportunities by months and introduces no nesting contradiction. It does not belong to the original 274 EPSS-unobservable events, so it does not change the A/B/U split for that subset.

## Required interpretation and implementation cautions

1. **Preserve the decision clock.** A precise Git timestamp cannot be compared with an EPSS decision point known only by calendar date. For same-day cases in this corrected pipeline, retain `HOLD` unless the EPSS timestamps are contemporaneous and both verified Git time and trustworthy immutable first-blob `datePublished` fall strictly on the same side of both timestamps. Do not infer that a record entering `PUBLISHED` state at some time on Tuesday necessarily preceded a Tuesday ranking snapshot. In the full 749-event historical pass, 36 records land on the same calendar date as their last eligible Tuesday (32 originally EPSS-unobservable and 4 EPSS-observable); those 36 require this gate rather than silent ordering.

2. **Treat the release time as corroboration, not metadata repair.** The first Git `PUBLISHED` state and the first official release containing that state are direct observations. They do not validate a current `datePublished` value or convert a missing historical field into a fabricated timestamp.

3. **Prove absence from a complete state.** Absence from a delta archive alone is insufficient because deltas are relative to the daily baseline. Use the exact prior tagged tree, or reconstruct the daily baseline plus deltas.

4. **Follow historical paths explicitly.** Records before the repository-wide rename on 2023-03-28 may appear under `preview_cves/...`; later states use `cves/...`. The rename commit is [`4100e8bcf1e849a7ac87395bb3d86d23b39ea267`](https://github.com/CVEProject/cvelistV5/commit/4100e8bcf1e849a7ac87395bb3d86d23b39ea267). A search limited to the current path can falsely left-censor early 2023 evidence.

5. **Inspect state, not only file creation.** Process a file's changing commits in chronological order and accept the first state that actually parses as `PUBLISHED`. File existence, reservation, rejection, or the first commit touching a path is not automatically publication.

6. **Do not assume every nominal release exists or carries a full asset set.** Some hours are absent, consecutive tags may point to the same commit, and early 2023 releases can contain only release notes. Use observed refs and release metadata, never generated tag names as evidence.

7. **Hash canonical source bytes.** Git checkouts may apply line-ending conversion. Calculate SHA-256 from canonical Git/raw bytes and downloaded release bytes, not from a possibly converted working-tree file. Retain the Git commit and blob identifiers alongside SHA-256.

8. **Keep left-censoring explicit.** For records already `PUBLISHED` in an official snapshot before the first eligible study decision, that snapshot establishes only that the admitted official source contained a `PUBLISHED` record by that time. Record the observation as left-censored rather than inventing an original publication date.

## Recommended per-event evidence fields

Each publication-ledger row should retain at least:

- exact CVE ID and historical path;
- first commit whose record state is `PUBLISHED`;
- Git author/committer UTC time, parent SHA, tree SHA, and blob OID;
- canonical record SHA-256 and byte count;
- prior and next observed hourly tag names and target SHAs;
- release IDs, release publication times, asset IDs, sizes, URLs, and locally calculated asset SHA-256 where used;
- current metadata values as cross-checks only;
- known-issue and discrepancy flags;
- `KEEP` or `HOLD`, with a machine-readable reason;
- explicit date/timestamp comparison rule used at the decision boundary.

This evidence design supports a defensible historical official-CVE-`PUBLISHED`-state layer while preserving uncertainty and preventing current metadata from manufacturing past source states. It does not make claims about other public sources.
