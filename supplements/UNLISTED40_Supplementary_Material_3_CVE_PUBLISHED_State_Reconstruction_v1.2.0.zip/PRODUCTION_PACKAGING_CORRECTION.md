# Production packaging correction

The accepted reconstruction's scientific values and classification algorithm are unchanged. This correction reconciles the package's input SHA-256 guards with transformations already applied when the accepted evidence was prepared for Supplementary Material 3.

## Demonstrated defect

The original Supplementary Material 3 package had sanitized input files but retained four SHA-256 values from the original accepted files. Running its reconstruction command from a fresh extraction exited with code 1 at the locked-cohort hash guard, before it accessed the cvelistV5 repository or EPSS cache. Consequently, the older clean-run record does not by itself establish that the production package can execute.

## Admitted transformations

The reported event input is byte-identical to the accepted input. The locked cohort and first-PUBLISHED evidence differ only by CRLF-to-LF line-ending normalization. In each of the two 174-row EPSS manifests, the absolute local `cache_file` value has been replaced by the same filename, and line endings were normalized. Every other CSV cell, header, row order, source hash, byte count, date, timestamp, and URL is unchanged. The cache-file transformation removes machine-specific paths; it does not change which source snapshot is admitted.

The production code now pins those exact delivered bytes. Hash checks remain mandatory; no bypass or fallback was introduced. This changes no reconstruction algorithm, event membership, scientific field, same-day rule, or evidence boundary. The locked values remain `749 / 475 / 274 / 41`, decomposition `251 / 0 / 23`, and deterministic bounds `A = 251–274`, `B = 0–23`.

## Original and production input hashes

| Logical input | Accepted R2 SHA-256 | Production SHA-256 |
|---|---|---|
| Reported event input | `10a9d3c4b0e53511d017afb567cf45798e63f97228902b6ea703c9b1f7ecd762` | `10a9d3c4b0e53511d017afb567cf45798e63f97228902b6ea703c9b1f7ecd762` |
| Locked cohort | `322b0999465ddf211e7730d2f57b6bb6f13095ca27e736b229a523acb5d80451` | `0f14b5b07766dbd90869f217afe7d87be99b96a24f408ec6f3fee2455b641af0` |
| EPSS manifest | `4678d8b4500d1afa16b2f5a0b828376d92a5a4897b4cb98dfc6bcc9bf787d898` | `96f89f06b43ac8af5c1a05cf4f24ce46b87d502efbce9dc7e187362e86616509` |
| EPSS live-acquisition manifest | `157878a891b7ec1d6ff187c46005d481ebf0ff6c3c7d87acd71b08a94300e053` | `896e39c824db04371925d820713984cee8422c30e4a753467384525baad352a1` |
| First-PUBLISHED state evidence | `ff9fae86b658c92feea7fba7be83b32d0e66a8068760a3bdbcb4030ddaa7f618` | `44c420e58de05f50c1f6fbca7616859ee1685e55e1a54ef262dead3c6a74160e` |

## Regression validation

The standard-library `code/test_packaged_inputs.py` checks all five delivered paths against the reconstruction module's exact input hashes. It creates altered temporary copies and verifies that the reconstruction guard rejects modified bytes. With `--accepted-root`, it independently verifies the accepted originals' pinned hashes and proves that the delivered files contain only the transformations above.

```text
python -B code/test_packaged_inputs.py
python -B code/test_packaged_inputs.py --accepted-root <ACCEPTED_R2_ROOT> --output <RESULT_JSON>
```

All five delivered-input checks, all five modified-byte rejection checks, and all five accepted-source comparisons passed. Separate helper checks also rejected unapproved CSV-cell changes for each of the five inputs. These tests need neither the full CVE Git history nor the EPSS cache. A fresh production reconstruction and independent clean-root replay completed successfully: all eight output files are byte-identical between runs, all six scientific CSV outputs are byte-identical to accepted R2, and every scientific summary field is unchanged. See `outputs/clean_root_rerun_log.md` and the JSON comparison; the replay used the admitted historical ledger, pinned Git source and all 174 historical EPSS snapshots without reacquiring the entire history.

## Public-release notices

The production release now includes the project's existing MIT license without changing its copyright designation, the verified MITRE CVE copyright notice and complete official license/disclaimer, and explicit third-party attribution. The CVE text is verified against the official CVE website source at the commit identified in `THIRD_PARTY_CVE_LICENSE.txt`. Existing third-party restrictions remain applicable. Adding these notices and updating the production README does not change any file in `code/`, `inputs/`, `evidence/` or `outputs/`; the recorded fresh production rerun therefore applies to the identical scientific payload. The release manifest is regenerated to cover the added notices and documentation edits.
