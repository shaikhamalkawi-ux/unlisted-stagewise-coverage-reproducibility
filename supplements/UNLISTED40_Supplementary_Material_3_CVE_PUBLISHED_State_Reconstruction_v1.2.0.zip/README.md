# Official CVE PUBLISHED-State Reconstruction Reproducibility Package

This supplementary package supports the evidence-bounded reconstruction of official CVE `PUBLISHED` state for the locked 749-event cohort used in the accompanying manuscript. It is separate from the stagewise EPSS coverage package.

Accompanying manuscript: **Before Ranking Begins: A Multi-Year Study of Coverage Loss in EPSS-Based Vulnerability Triage**. Author: Ghassan Malkawi, Higher Colleges of Technology, United Arab Emirates.

## Scientific boundary

The reconstruction identifies the first observed `PUBLISHED` state in the admitted official cvelistV5 Git/release history. It does **not** establish the first date on which a vulnerability was known through vendor advisories, mailing lists, exploit reports, or other public sources. It does not estimate exploit onset, causality, remediation, or enterprise risk reduction.

## Principal result

Among the 274 EPSS-unobservable outcomes, 251 had no admitted preceding official CVE `PUBLISHED` state, 0 had an admitted preceding `PUBLISHED` state while remaining absent from all eligible EPSS snapshots, and 23 remained HOLD. Across the full cohort the cross-tab is 472/0, 0/251, and HOLD 3/23 for EPSS-observable/EPSS-unobservable. Deterministic unresolved-allocation bounds are A=251--274 and B=0--23.

## Reproduction boundary

The code expects the pinned cvelistV5 repository and the 174 historical EPSS gzip snapshots identified by the included manifests. Those large source caches are not redistributed in this ZIP. Their identities, expected hashes, and acquisition provenance are recorded in the included evidence and output files. The production clean-root log records a full reconstruction replay against those pinned read-only caches and the admitted historical ledger. It is not a new acquisition of the complete historical source. The machine-readable comparison records byte-identity of deterministic outputs between two production runs.

## Production correction and exact rerun commands

The 2026-09-22 production correction updates four stale input-hash constants to the reviewed path-sanitized/LF inputs actually shipped in this package. No scientific field, cohort, classification rule, timestamp gate, or result changed. See `PRODUCTION_PACKAGING_CORRECTION.md`. The exact-hash gate remains enforced; do not normalize or edit input files after extraction.

Requirements: Python 3.12 (standard library only), Git on PATH, the cvelistV5 checkout at `4bc05add0932bd642880fc7a46dfb589889217eb`, and the 174 gzip snapshots with the included manifest hashes. No scientific outputs are created when a required hash or source gate fails. Network access may be needed by Git if immutable objects are not already present in a partial clone. Raw source archives are not supplied here.

From this extracted package, replace the two external-cache placeholders. The following commands are each a single line and work in a normal shell:

```text
python -B code/test_packaged_inputs.py --output package_input_tests.json
python -B code/reconstruct_cve_published_state.py --baseline-event-input inputs/reported_public_event_input.csv --locked-cohort inputs/locked749_cisa_cohort.csv --epss-cache <EPSS_CACHE> --epss-manifest inputs/shadowserver_epss_decision_manifest.csv --epss-live-manifest inputs/shadowserver_epss_decision_manifest_live_acquisition.csv --history-evidence evidence/first_published_state_evidence.csv --cvelist-repo <CVELIST_REPO> --output-dir fresh_output
python -B code/test_fail_closed.py --baseline inputs/reported_public_event_input.csv --manifest inputs/shadowserver_epss_decision_manifest.csv --epss-cache <EPSS_CACHE> --cvelist-repo <CVELIST_REPO> --output fresh_fail_closed_tests.json
```

For an independent-root replay, extract another copy into a new empty directory, run the same commands there, and compare the two `fresh_output` directories:

```text
python -B code/compare_clean_rerun.py <FIRST_OUTPUT> <CLEAN_OUTPUT> clean_comparison.json
```

Eight uppercase-named reconstruction outputs are created in `fresh_output`. This delivery uses lower-case descriptive filenames under `outputs/` and `evidence/`; `outputs/production_output_mapping.json` records the exact mapping and hashes. Six scientific CSVs and the summary must preserve all scientific values from accepted R2. Acquisition provenance appropriately records the revised production input hashes and file names.

Optional independent transformation audit, with the accepted R2 review package extracted separately:

```text
python -B code/test_packaged_inputs.py --accepted-root <ACCEPTED_R2_ROOT> --output accepted_input_equivalence.json
```

This is the production supplementary artifact for the UNLISTED40 scientific baseline. The release adds the existing first-party MIT license and verified third-party notices to the previously corrected artifact; scientific code, inputs, evidence and outputs are byte-identical. The presence of this ZIP does not itself assert that a GitHub release, DOI or journal submission has been published.

## Copyright and third-party sources

The project's own software and documentation retain the existing MIT license and its original copyright designation in `LICENSE.txt`. Third-party CVE content retains the MITRE copyright designation and the complete official CVE terms in `THIRD_PARTY_CVE_LICENSE.txt`. `THIRD_PARTY_DATA_NOTICE.md` identifies CISA, FIRST EPSS, Shadowserver and CVE provenance and preserves their source terms. Keep these notices with copies of this package. No raw historical source cache is included.

## Contents

- `code/`: deterministic reconstruction, historical-state extraction, adversarial tests, and audit helpers.
- `inputs/`: locked 749-row cohort/event inputs and EPSS source manifests.
- `evidence/`: immutable first-state evidence, same-day gates, timestamp probes, and pinned official-source documentation.
- `outputs/`: event ledger, anomaly/known-issue ledgers, results, timing diagnostics, fail-closed test results, and clean-root comparison.
- `OFFICIAL_SOURCE_EVIDENCE_NOTE.md`: evidence-source and interpretation boundary.
- `SHA256SUMS.txt`: package integrity manifest.
- `LICENSE.txt`, `THIRD_PARTY_CVE_LICENSE.txt`, `THIRD_PARTY_DATA_NOTICE.md`: first-party license and retained third-party notices.

The same-day admission rule fails closed unless first-PUBLISHED Git time and verified immutable first-blob `datePublished` concordantly fall strictly before or strictly after both contemporaneous EPSS timestamps.
