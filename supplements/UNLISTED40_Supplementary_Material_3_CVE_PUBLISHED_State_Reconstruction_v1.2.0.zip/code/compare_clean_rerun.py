#!/usr/bin/env python3
"""Compare deterministic primary and clean-root reconstruction outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("primary", type=Path)
    parser.add_argument("clean", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    primary_files = {path.name: path for path in args.primary.iterdir() if path.is_file()}
    clean_files = {path.name: path for path in args.clean.iterdir() if path.is_file()}
    names = sorted(set(primary_files) | set(clean_files))
    rows = []
    for name in names:
        left = primary_files.get(name)
        right = clean_files.get(name)
        left_hash = digest(left) if left else ""
        right_hash = digest(right) if right else ""
        rows.append(
            {
                "file": name,
                "primary_sha256": left_hash,
                "clean_sha256": right_hash,
                "byte_identical": bool(left and right and left_hash == right_hash),
            }
        )
    summary = {
        "status": "PASS" if rows and all(row["byte_identical"] for row in rows) else "FAIL",
        "files_compared": len(rows),
        "byte_identical_files": sum(row["byte_identical"] for row in rows),
        "comparisons": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if summary["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
