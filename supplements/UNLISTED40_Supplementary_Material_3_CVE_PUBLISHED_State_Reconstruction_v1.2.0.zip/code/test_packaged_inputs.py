#!/usr/bin/env python3
"""Validate delivered input pins and optional equivalence to accepted evidence.

From an extracted Supplement 3 package:
    python -B code/test_packaged_inputs.py
    python -B code/test_packaged_inputs.py --accepted-root <ACCEPTED_R2_ROOT>
    python -B code/test_packaged_inputs.py --output <RESULT_JSON>

The accepted-root check permits CRLF-to-LF normalization and, for the two
EPSS manifests only, replacing an absolute cache_file path with its basename.
Every other CSV cell must match. No evidence files are modified. Mutated-byte
rejection checks use temporary copies. Any failed check exits nonzero.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import tempfile
from pathlib import Path, PurePosixPath, PureWindowsPath


INPUTS = {
    "baseline_event_input": (
        "inputs/reported_public_event_input.csv",
        "evidence/source_inputs/reported_public_event_input.csv",
        "10a9d3c4b0e53511d017afb567cf45798e63f97228902b6ea703c9b1f7ecd762",
    ),
    "locked_cohort": (
        "inputs/locked749_cisa_cohort.csv",
        "evidence/source_inputs/locked749_cisa_cohort.csv",
        "322b0999465ddf211e7730d2f57b6bb6f13095ca27e736b229a523acb5d80451",
    ),
    "epss_manifest": (
        "inputs/shadowserver_epss_decision_manifest.csv",
        "evidence/source_inputs/shadowserver_epss_decision_manifest.csv",
        "4678d8b4500d1afa16b2f5a0b828376d92a5a4897b4cb98dfc6bcc9bf787d898",
    ),
    "epss_live_manifest": (
        "inputs/shadowserver_epss_decision_manifest_live_acquisition.csv",
        "evidence/source_inputs/shadowserver_epss_decision_manifest_live_acquisition.csv",
        "157878a891b7ec1d6ff187c46005d481ebf0ff6c3c7d87acd71b08a94300e053",
    ),
    "history_evidence": (
        "evidence/first_published_state_evidence.csv",
        "evidence/CVELIST_FIRST_PUBLISHED_EVIDENCE.csv",
        "ff9fae86b658c92feea7fba7be83b32d0e66a8068760a3bdbcb4030ddaa7f618",
    ),
}
MANIFEST_KEYS = {"epss_manifest", "epss_live_manifest"}


def sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def read_csv(content: bytes):
    reader = csv.reader(io.StringIO(content.decode("utf-8-sig"), newline=""))
    records = list(reader)
    if not records:
        raise ValueError("empty CSV")
    header, rows = records[0], records[1:]
    if len(header) != len(set(header)) or any(not field for field in header):
        raise ValueError("blank or duplicate CSV column")
    if any(len(row) != len(header) for row in rows):
        raise ValueError("CSV row width differs from header")
    return header, rows


def compare_accepted(logical_name: str, delivered: bytes, accepted: bytes):
    """Reject any change beyond the explicitly admitted production changes."""
    left_header, left_rows = read_csv(delivered)
    right_header, right_rows = read_csv(accepted)
    if left_header != right_header or len(left_rows) != len(right_rows):
        raise ValueError("CSV header or row count differs from accepted evidence")
    normalized = accepted.replace(b"\r\n", b"\n")
    transformed = normalized
    changed_cache_rows = 0
    cache_index = None
    if logical_name in MANIFEST_KEYS:
        if "cache_file" not in left_header:
            raise ValueError("EPSS manifest lacks cache_file")
        cache_index = left_header.index("cache_file")
    for row_number, (left, right) in enumerate(zip(left_rows, right_rows), 2):
        for column, (new, old) in enumerate(zip(left, right)):
            if new == old:
                continue
            if column != cache_index:
                raise ValueError(
                    f"unapproved CSV change at row {row_number}, column {left_header[column]}"
                )
            windows_path = PureWindowsPath(old)
            posix_path = PurePosixPath(old)
            if windows_path.is_absolute():
                basename = windows_path.name
            elif posix_path.is_absolute():
                basename = posix_path.name
            else:
                raise ValueError(f"original cache_file is not absolute at row {row_number}")
            if not basename or new != basename or "/" in new or "\\" in new:
                raise ValueError(f"cache_file change is not absolute-to-basename at row {row_number}")
            transformed = transformed.replace(old.encode("utf-8"), new.encode("utf-8"))
            changed_cache_rows += 1
    if delivered not in (accepted, normalized, transformed):
        raise ValueError("byte changes exceed admitted line-ending/path transformations")
    return {
        "rows": len(left_rows),
        "all_other_csv_cells_equal": True,
        "cache_file_paths_replaced": changed_cache_rows,
        "crlf_to_lf_normalization": accepted != normalized and delivered != accepted,
        "byte_identical_to_accepted": delivered == accepted,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--accepted-root", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    package_root = Path(__file__).resolve().parent.parent
    results = []

    try:
        import reconstruct_cve_published_state as reconstruction
        pins = reconstruction.EXPECTED_INPUT_SHA256
        if set(pins) != set(INPUTS):
            raise ValueError("reconstruction input-pin keys differ from the five required inputs")
    except Exception as exc:
        results.append({"check": "load_reconstruction_input_pins", "status": "FAIL", "detail": str(exc)})
    else:
        with tempfile.TemporaryDirectory(prefix="cve_packaged_input_test_") as temporary:
            for logical_name, (relative, original_relative, original_sha) in INPUTS.items():
                path = package_root / relative
                item = {"input": logical_name, "file": relative, "expected_sha256": pins[logical_name]}
                try:
                    content = path.read_bytes()
                    item["actual_sha256"] = sha256(content)
                    reconstruction.require_sha256(path, pins[logical_name], logical_name=logical_name)
                    mutated = Path(temporary) / (logical_name + ".csv")
                    mutated.write_bytes(content + b"\x00")
                    try:
                        reconstruction.require_sha256(mutated, pins[logical_name], logical_name=logical_name)
                    except ValueError:
                        item["modified_bytes_rejected"] = True
                    else:
                        raise ValueError("modified bytes were accepted by the reconstruction hash guard")
                    if args.accepted_root is not None:
                        original = (args.accepted_root / original_relative).read_bytes()
                        item["accepted_sha256"] = sha256(original)
                        if item["accepted_sha256"] != original_sha:
                            raise ValueError("accepted source is not the pinned independently reviewed R2 input")
                        item["accepted_equivalence"] = compare_accepted(logical_name, content, original)
                    item["status"] = "PASS"
                except Exception as exc:
                    item["status"] = "FAIL"
                    item["detail"] = str(exc)
                results.append(item)

    passed = len(results) == len(INPUTS) and all(row["status"] == "PASS" for row in results)
    report = {
        "status": "PASS" if passed else "FAIL",
        "accepted_source_equivalence_checked": args.accepted_root is not None,
        "inputs_required": len(INPUTS),
        "checks_passed": sum(row["status"] == "PASS" for row in results),
        "results": results,
    }
    serialized = json.dumps(report, indent=2) + "\n"
    print(serialized, end="")
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(serialized, encoding="utf-8")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
