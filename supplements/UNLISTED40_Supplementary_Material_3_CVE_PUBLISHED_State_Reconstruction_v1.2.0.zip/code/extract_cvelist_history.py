#!/usr/bin/env python3
"""Reconstruct first Git evidence of PUBLISHED state for a CVE cohort.

The cvelistV5 repository used ``preview_cves/`` before the mass move to
``cves/`` on 2023-03-28.  This program scans additions under both roots in one
Git traversal, selects the earliest repository appearance for each requested
CVE, and verifies the immutable blob at that commit.  Records already present
in the repository root commit are explicitly marked left-censored.

The normal fast path expects the first repository appearance to be PUBLISHED.
Any exception is emitted to ``needs_full_history.csv`` and must be resolved by
chronologically inspecting every later version; it is never coerced.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import http.client
import json
import pathlib
import subprocess
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass


REMOTE = "https://github.com/CVEProject/cvelistV5.git"
RAW_BASE = "https://raw.githubusercontent.com/CVEProject/cvelistV5"


def cve_relpath(cve_id: str, root: str) -> str:
    _, year, serial = cve_id.split("-", 2)
    return f"{root}/{year}/{int(serial) // 1000}xxx/{cve_id}.json"


def git(repo: pathlib.Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
    )
    return result.stdout.strip()


@dataclass(frozen=True)
class Addition:
    cve_id: str
    path: str
    commit: str
    commit_time: str
    parents: str
    sequence: int


def scan_additions(repo: pathlib.Path, wanted: dict[str, str]) -> dict[str, Addition]:
    command = [
        "git",
        "-C",
        str(repo),
        "log",
        "HEAD",
        "--reverse",
        "--topo-order",
        "--diff-filter=A",
        "--no-renames",
        "--format=@@COMMIT%x09%H%x09%cI%x09%P",
        "--name-only",
        "--",
        "preview_cves",
        "cves",
    ]
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="strict",
        bufsize=1,
    )
    assert process.stdout is not None
    current: tuple[str, str, str] | None = None
    first: dict[str, Addition] = {}
    sequence = 0
    for raw_line in process.stdout:
        line = raw_line.rstrip("\r\n")
        if line.startswith("@@COMMIT\t"):
            fields = line.split("\t", 3)
            if len(fields) != 4:
                raise RuntimeError(f"malformed commit marker: {line!r}")
            current = (fields[1], fields[2], fields[3])
            sequence += 1
        elif line in wanted and current is not None:
            cve_id = wanted[line]
            if cve_id not in first:
                first[cve_id] = Addition(
                    cve_id=cve_id,
                    path=line,
                    commit=current[0],
                    commit_time=current[1],
                    parents=current[2],
                    sequence=sequence,
                )
    stderr = process.stderr.read() if process.stderr is not None else ""
    return_code = process.wait()
    if return_code:
        raise RuntimeError(f"git log failed ({return_code}): {stderr}")
    return first


def fetch_blob(addition: Addition, cache: pathlib.Path) -> dict[str, str]:
    url = f"{RAW_BASE}/{addition.commit}/{addition.path}"
    destination = cache / addition.commit / addition.path
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        body = destination.read_bytes()
    else:
        last_error: Exception | None = None
        for attempt in range(6):
            try:
                request = urllib.request.Request(
                    url, headers={"User-Agent": "UNLISTED-CVE-history-audit/1.0"}
                )
                with urllib.request.urlopen(request, timeout=90) as response:
                    body = response.read()
                destination.write_bytes(body)
                break
            except (
                urllib.error.URLError,
                TimeoutError,
                http.client.HTTPException,
                OSError,
            ) as error:
                last_error = error
                time.sleep(2**attempt)
        else:
            raise RuntimeError(f"failed to fetch {addition.cve_id}: {last_error}")

    record = json.loads(body)
    metadata = record.get("cveMetadata", {})
    cna = record.get("containers", {}).get("cna", {}).get("providerMetadata", {})
    return {
        "cve_id": addition.cve_id,
        "first_evidence_commit": addition.commit,
        "first_evidence_commit_time_utc": addition.commit_time,
        "first_evidence_parents": addition.parents,
        "first_evidence_path": addition.path,
        "first_evidence_state": str(metadata.get("state", "")),
        "first_blob_date_published": str(metadata.get("datePublished", "")),
        "first_blob_date_updated": str(metadata.get("dateUpdated", "")),
        "first_blob_assigner_org_id": str(metadata.get("assignerOrgId", "")),
        "first_blob_assigner_short_name": str(metadata.get("assignerShortName", "")),
        "first_blob_cna_org_id": str(cna.get("orgId", "")),
        "first_blob_cna_short_name": str(cna.get("shortName", "")),
        "first_blob_sha256": hashlib.sha256(body).hexdigest(),
        "first_blob_url": url,
        "history_sequence": str(addition.sequence),
    }


def write_csv(path: pathlib.Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        if not rows:
            handle.write("")
            return
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cohort_csv", type=pathlib.Path)
    parser.add_argument("repo", type=pathlib.Path)
    parser.add_argument("output_csv", type=pathlib.Path)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--cache", type=pathlib.Path, required=True)
    parser.add_argument("--workers", type=int, default=16)
    args = parser.parse_args()

    actual_head = git(args.repo, "rev-parse", "HEAD")
    if actual_head != args.expected_head:
        raise SystemExit(f"HEAD mismatch: expected {args.expected_head}, got {actual_head}")
    remote = git(args.repo, "config", "--get", "remote.origin.url")
    if remote.rstrip("/").removesuffix(".git") != REMOTE.removesuffix(".git"):
        raise SystemExit(f"unexpected origin: {remote}")

    with args.cohort_csv.open(newline="", encoding="utf-8-sig") as handle:
        ids = sorted({row["outcome_id"].strip() for row in csv.DictReader(handle)})
    if len(ids) != 749:
        raise SystemExit(f"expected 749 unique outcome_id values; found {len(ids)}")

    wanted: dict[str, str] = {}
    for cve_id in ids:
        wanted[cve_relpath(cve_id, "preview_cves")] = cve_id
        wanted[cve_relpath(cve_id, "cves")] = cve_id

    additions = scan_additions(args.repo, wanted)
    missing = sorted(set(ids) - set(additions))
    if missing:
        raise SystemExit(f"no addition found for {len(missing)} CVEs: {missing[:10]}")

    root_commits = set(git(args.repo, "rev-list", "--max-parents=0", "HEAD").splitlines())
    rows: list[dict[str, str]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(fetch_blob, addition, args.cache): cve_id
            for cve_id, addition in additions.items()
        }
        for future in as_completed(futures):
            row = future.result()
            row["left_censored_at_repository_start"] = str(
                row["first_evidence_commit"] in root_commits
            ).lower()
            rows.append(row)
    rows.sort(key=lambda row: row["cve_id"])
    write_csv(args.output_csv, rows)

    unresolved = [row for row in rows if row["first_evidence_state"] != "PUBLISHED"]
    unresolved_path = args.output_csv.with_name("needs_full_history.csv")
    write_csv(unresolved_path, unresolved)
    states: dict[str, int] = {}
    for row in rows:
        states[row["first_evidence_state"]] = states.get(row["first_evidence_state"], 0) + 1
    print(
        "FIRST_PUBLISHED_FAST_PATH: "
        f"{'PASS' if not unresolved else 'HOLD'}; records={len(rows)}; "
        f"states={json.dumps(states, sort_keys=True)}; "
        f"left_censored={sum(row['left_censored_at_repository_start'] == 'true' for row in rows)}; "
        f"needs_full_history={len(unresolved)}"
    )


if __name__ == "__main__":
    main()
