#!/usr/bin/env python3
"""Probe timestamp evidence in the official historical EPSS archive.

This deliberately distinguishes logical score-date metadata from evidence of
wall-clock publication.  It reads the official Git archive, the official
download endpoint's HTTP metadata, and the gzip container metadata.
"""

from __future__ import annotations

import csv
import datetime as dt
import gzip
import hashlib
import io
import pathlib
import subprocess
import urllib.request


DATES = (
    "2023-03-07",
    "2023-04-11",
    "2023-07-11",
    "2023-08-08",
    "2023-09-12",
    "2023-09-19",
    "2023-10-31",
    "2023-12-05",
    "2024-01-16",
    "2024-02-13",
    "2024-03-05",
    "2024-05-14",
    "2024-05-28",
    "2024-08-13",
    "2024-09-10",
    "2024-10-08",
    "2024-11-19",
    "2024-11-26",
    "2024-12-17",
    "2025-02-04",
    "2025-03-11",
)

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE / "epss_scores_history"
OUT = HERE / "epss_pre2025_timestamp_probe.csv"


def git(*args: str, binary: bool = False) -> bytes | str:
    result = subprocess.run(
        ["git", "-C", str(REPO), *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout if binary else result.stdout.decode("utf-8").strip()


def first_commit_for_path(path: str) -> tuple[str, str, str]:
    line = git(
        "log",
        "--all",
        "--reverse",
        "--format=%H%x09%cI%x09%s",
        "--",
        path,
    ).splitlines()[0]
    return tuple(line.split("\t", 2))  # type: ignore[return-value]


def main() -> None:
    rows: list[dict[str, str | int]] = []
    for date in DATES:
        year = date[:4]
        path = f"{year}/epss_scores-{date}.csv.gz"
        payload = git("show", f"HEAD:{path}", binary=True)
        assert isinstance(payload, bytes)

        with gzip.GzipFile(fileobj=io.BytesIO(payload), mode="rb") as stream:
            first_line = stream.readline().decode("utf-8").strip()
            gzip_mtime = stream.mtime

        request = urllib.request.Request(
            f"https://epss.empiricalsecurity.com/epss_scores-{date}.csv.gz",
            method="HEAD",
            headers={"User-Agent": "UNLISTED-CVE-publication-reconstruction/1.0"},
        )
        with urllib.request.urlopen(request, timeout=60) as response:
            headers = response.headers
            final_url = response.url

        commit, commit_time, subject = first_commit_for_path(path)
        rows.append(
            {
                "score_date": date,
                "archive_path": path,
                "internal_header": first_line,
                "gzip_mtime_epoch": gzip_mtime if gzip_mtime is not None else "",
                "gzip_mtime_utc": (
                    dt.datetime.fromtimestamp(gzip_mtime, dt.timezone.utc).isoformat()
                    if gzip_mtime is not None
                    else ""
                ),
                "http_final_url": final_url,
                "http_last_modified": headers.get("Last-Modified", ""),
                "http_etag": headers.get("ETag", ""),
                "http_x_amz_version_id": headers.get("x-amz-version-id", ""),
                "content_length": len(payload),
                "sha256": hashlib.sha256(payload).hexdigest(),
                "first_git_commit": commit,
                "first_git_commit_time": commit_time,
                "first_git_commit_subject": subject,
            }
        )

    with OUT.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows: {OUT}")


if __name__ == "__main__":
    main()
