#!/usr/bin/env python3
"""Fetch current cvelistV5 records for the locked UNLISTED cohort.

This is a convenience probe only.  Historical classification must use Git
history; the current metadata collected here is used to identify candidate
known-issue records and to cross-check path construction.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import http.client
import json
import pathlib
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed


def cve_path(cve_id: str) -> str:
    _, year, serial = cve_id.split("-", 2)
    bucket = f"{int(serial) // 1000}xxx"
    return f"cves/{year}/{bucket}/{cve_id}.json"


def fetch_one(cve_id: str, commit: str, cache_dir: pathlib.Path) -> dict[str, str]:
    rel = cve_path(cve_id)
    url = f"https://raw.githubusercontent.com/CVEProject/cvelistV5/{commit}/{rel}"
    destination = cache_dir / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        body = destination.read_bytes()
    else:
        last_error: Exception | None = None
        for attempt in range(5):
            try:
                request = urllib.request.Request(
                    url, headers={"User-Agent": "UNLISTED-CVE-history-audit/1.0"}
                )
                with urllib.request.urlopen(request, timeout=60) as response:
                    body = response.read()
                destination.write_bytes(body)
                break
            except (
                urllib.error.URLError,
                TimeoutError,
                http.client.HTTPException,
                OSError,
            ) as error:
                last_error = error
                time.sleep(2**attempt)
        else:
            raise RuntimeError(f"failed to fetch {cve_id}: {last_error}")

    record = json.loads(body)
    metadata = record.get("cveMetadata", {})
    cna = record.get("containers", {}).get("cna", {}).get("providerMetadata", {})
    return {
        "cve_id": cve_id,
        "path": rel,
        "state": str(metadata.get("state", "")),
        "date_published": str(metadata.get("datePublished", "")),
        "date_updated": str(metadata.get("dateUpdated", "")),
        "date_reserved": str(metadata.get("dateReserved", "")),
        "assigner_org_id": str(metadata.get("assignerOrgId", "")),
        "assigner_short_name": str(metadata.get("assignerShortName", "")),
        "cna_org_id": str(cna.get("orgId", "")),
        "cna_short_name": str(cna.get("shortName", "")),
        "blob_sha256": hashlib.sha256(body).hexdigest(),
        "source_commit": commit,
        "source_url": url,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=pathlib.Path)
    parser.add_argument("output_csv", type=pathlib.Path)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--cache", type=pathlib.Path, required=True)
    parser.add_argument("--workers", type=int, default=16)
    args = parser.parse_args()

    with args.input_csv.open(newline="", encoding="utf-8-sig") as handle:
        ids = sorted({row["outcome_id"].strip() for row in csv.DictReader(handle)})
    if len(ids) != 749:
        raise SystemExit(f"expected 749 unique outcome_id values; found {len(ids)}")

    rows: list[dict[str, str]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(fetch_one, cve_id, args.commit, args.cache): cve_id
            for cve_id in ids
        }
        for future in as_completed(futures):
            rows.append(future.result())

    rows.sort(key=lambda row: row["cve_id"])
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"CURRENT_METADATA_FETCH: PASS ({len(rows)} records)")


if __name__ == "__main__":
    main()
