#!/usr/bin/env python3
"""Deterministic CVE-publication reconstruction for the locked study cohort.

Scientific boundary
-------------------
The admitted source state is established from the first historical cvelistV5
Git blob whose ``cveMetadata.state`` is ``PUBLISHED``.  This does not assert
availability or non-availability in vendor advisories or any other public
source.  For same-day ordering, an immutable ``datePublished`` from that first
blob is required, must fall outside the known date-integrity issue, and must
agree with the Git-versus-EPSS timestamp order; otherwise the row remains HOLD.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
import platform
import re
import statistics
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Iterable


EXPECTED_HEAD = "4bc05add0932bd642880fc7a46dfb589889217eb"
STUDY_OPEN = date(2023, 3, 7)
DECISION_END = date(2026, 6, 30)
KNOWN_ISSUE_START = date(2024, 5, 8)
KNOWN_ISSUE_END = date(2024, 6, 7)
EXPECTED_ROWS = 749
EXPECTED_OBSERVABLE = 475
EXPECTED_UNOBSERVABLE = 274
EXPECTED_TOP1000 = 41
EXPECTED_SAME_DAY_FIRST_SAMPLE = 39
EXPECTED_AFTER_FIRST_SAMPLE = 233
EXPECTED_NEVER_SAMPLED = 2
EXPECTED_SAME_DAY_PUBLISHED_STATE_BEFORE = {"CVE-2025-42999"}
EXPECTED_SAME_DAY_PUBLISHED_STATE_AFTER = {
    "CVE-2025-32756",
    "CVE-2025-4427",
    "CVE-2025-4428",
    "CVE-2025-59718",
    "CVE-2025-62215",
    "CVE-2025-6558",
    "CVE-2026-10520",
    "CVE-2026-22769",
    "CVE-2026-48282",
}
EXPECTED_SAME_DAY_HOLD = 26
BASELINE_PREVIEW_IMPORT_COMMIT = "d6edecc32f25a8194a51dd388cd5a110b0726561"
EXPECTED_CVELIST_ORIGIN = "https://github.com/CVEProject/cvelistV5.git"
EXPECTED_INPUT_SHA256 = {
    # Production inputs retain the reviewed LF/path-sanitized representation.
    # See PRODUCTION_PACKAGING_CORRECTION.md and test_packaged_inputs.py.
    # These pins change file identities only; scientific fields are unchanged.
    "baseline_event_input": "10a9d3c4b0e53511d017afb567cf45798e63f97228902b6ea703c9b1f7ecd762",
    "locked_cohort": "0f14b5b07766dbd90869f217afe7d87be99b96a24f408ec6f3fee2455b641af0",
    "epss_manifest": "96f89f06b43ac8af5c1a05cf4f24ce46b87d502efbce9dc7e187362e86616509",
    "epss_live_manifest": "896e39c824db04371925d820713984cee8422c30e4a753467384525baad352a1",
    "history_evidence": "44c420e58de05f50c1f6fbca7616859ee1685e55e1a54ef262dead3c6a74160e",
}
KNOWN_ISSUE_EXPECTED_CVE = "CVE-2024-37383"
KNOWN_ISSUE_EXPECTED_COMMIT = "868e1135389199d066f8b1cc6e8009c56084e678"
KNOWN_ISSUE_EXPECTED_COMMIT_TIME = "2024-06-07T03:30:57Z"
KNOWN_ISSUE_EXPECTED_CONTENT_SHA256 = "dd95adb955fe0a17ef364da726850c138ab6b940b9704762c3171e08cbcdaedc"
KNOWN_ISSUE_DELTA_SHA256 = "881fb25c3d61e6c7bd5dda98d0b332bc382e7e977993e40a7005d4d4b61886f5"


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fail(message: str) -> None:
    raise ValueError(message)


def require_sha256(path: Path, expected: str, *, logical_name: str) -> None:
    actual = sha256_path(path)
    if actual != expected:
        fail(f"locked input SHA-256 mismatch for {logical_name}: {actual} != {expected}")


def parse_bool(value: str, *, field: str) -> bool:
    normalized = (value or "").strip().lower()
    if normalized in {"true", "1", "yes"}:
        return True
    if normalized in {"false", "0", "no"}:
        return False
    fail(f"invalid Boolean in {field}: {value!r}")


def parse_iso_date(value: str, *, field: str) -> date:
    text = (value or "").strip()
    if not text:
        fail(f"blank {field}")
    try:
        return date.fromisoformat(text[:10])
    except ValueError as exc:
        raise ValueError(f"invalid date in {field}: {value!r}") from exc


def parse_iso_datetime(value: str, *, field: str) -> datetime:
    text = (value or "").strip()
    if not text:
        fail(f"blank {field}")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f"invalid datetime in {field}: {value!r}") from exc
    if parsed.tzinfo is None:
        fail(f"timezone-free datetime in {field}: {value!r}")
    return parsed.astimezone(timezone.utc)


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        if not fields or len(fields) != len(set(fields)):
            fail(f"invalid or duplicate CSV header in {path.name}")
        rows = list(reader)
    return fields, rows


def require_columns(fields: Iterable[str], required: Iterable[str], *, source: str) -> None:
    missing = sorted(set(required) - set(fields))
    if missing:
        fail(f"{source} missing required columns: {missing}")


def require_unique(rows: list[dict[str, str]], field: str, *, source: str) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for row in rows:
        value = (row.get(field) or "").strip()
        if not value:
            fail(f"{source} has blank {field}")
        if value in result:
            fail(f"{source} has duplicate {field}: {value}")
        result[value] = row
    return result


def expected_tuesdays() -> list[date]:
    dates = []
    current = STUDY_OPEN
    while current <= DECISION_END:
        if current.weekday() != 1:
            fail(f"internal schedule boundary is not Tuesday: {current}")
        dates.append(current)
        current += timedelta(days=7)
    return dates


def cve_path(cve_id: str) -> Path:
    match = re.fullmatch(r"CVE-(\d{4})-(\d{4,})", cve_id)
    if not match:
        fail(f"invalid CVE ID: {cve_id}")
    year, number = match.groups()
    return Path("cves") / year / f"{int(number) // 1000}xxx" / f"{cve_id}.json"


def load_baseline(path: Path) -> dict[str, dict]:
    fields, rows = read_csv(path)
    require_columns(
        fields,
        [
            "outcome_id",
            "future_outcome_date",
            "source_observable",
            "best_conservative_rank_within_horizon",
            "best_decision_date_within_horizon",
        ],
        source=path.name,
    )
    indexed = require_unique(rows, "outcome_id", source=path.name)
    result = {}
    for cve_id, row in indexed.items():
        rank_text = (row.get("best_conservative_rank_within_horizon") or "").strip()
        rank = float(rank_text) if rank_text else None
        best_date_text = (row.get("best_decision_date_within_horizon") or "").strip()
        result[cve_id] = {
            "kev_date": parse_iso_date(row["future_outcome_date"], field="future_outcome_date"),
            "source_observable": parse_bool(row["source_observable"], field="source_observable"),
            "best_rank": rank,
            "best_decision_date": parse_iso_date(best_date_text, field="best_decision_date") if best_date_text else None,
            "top1000_captured": rank is not None and rank <= 1000,
            "best_score": (row.get("best_score_within_horizon") or "").strip(),
        }
    if len(result) != EXPECTED_ROWS:
        fail(f"baseline row count {len(result)} != {EXPECTED_ROWS}")
    if sum(item["source_observable"] for item in result.values()) != EXPECTED_OBSERVABLE:
        fail("baseline source-observable count does not match locked result")
    if sum(not item["source_observable"] for item in result.values()) != EXPECTED_UNOBSERVABLE:
        fail("baseline source-unobservable count does not match locked result")
    if sum(item["top1000_captured"] for item in result.values()) != EXPECTED_TOP1000:
        fail("baseline Top-1000 count does not match locked result")
    return result


def load_locked_cohort(path: Path) -> dict[str, date]:
    fields, rows = read_csv(path)
    require_columns(fields, ["cveID", "dateAdded"], source=path.name)
    indexed = require_unique(rows, "cveID", source=path.name)
    result = {cve_id: parse_iso_date(row["dateAdded"], field="dateAdded") for cve_id, row in indexed.items()}
    if len(result) != EXPECTED_ROWS:
        fail(f"locked cohort row count {len(result)} != {EXPECTED_ROWS}")
    return result


def load_history(path: Path) -> dict[str, dict]:
    fields, rows = read_csv(path)
    require_columns(fields, ["cve_id"], source=path.name)
    indexed = require_unique(rows, "cve_id", source=path.name)
    result = {}
    for cve_id, row in indexed.items():
        # Normalize either the local all-change extractor schema or the
        # independently executed fast-path first-add extractor schema.
        if "first_evidence_commit" in fields:
            state = (row.get("first_evidence_state") or "").strip()
            commit_sha = (row.get("first_evidence_commit") or "").strip()
            item = {
                **row,
                "history_status": "PUBLISHED_EVIDENCE" if state == "PUBLISHED" else "NO_PUBLISHED_STATE",
                "first_published_commit_sha": commit_sha,
                "first_published_committer_time_utc": row.get("first_evidence_commit_time_utc", ""),
                "first_published_parent_shas": row.get("first_evidence_parents", ""),
                "first_published_path": row.get("first_evidence_path", ""),
                "first_published_git_blob_sha1": "",
                "first_published_content_sha256": row.get("first_blob_sha256", ""),
                "metadata_date_published_at_first_published": row.get("first_blob_date_published", ""),
                "metadata_date_updated_at_first_published": row.get("first_blob_date_updated", ""),
                "assigner_short_name_at_first_published": row.get("first_blob_assigner_short_name", ""),
                "prior_history_state": "ABSENT_IN_PRIOR_CANONICAL_PATH",
            }
            repository_root_censored = parse_bool(
                row.get("left_censored_at_repository_start") or "false",
                field="left_censored_at_repository_start",
            )
        else:
            require_columns(
                fields,
                [
                    "history_status",
                    "first_published_commit_sha",
                    "first_published_committer_time_utc",
                    "first_published_path",
                    "first_published_content_sha256",
                    "history_left_censored_at_repository_root",
                ],
                source=path.name,
            )
            item = dict(row)
            commit_sha = (row.get("first_published_commit_sha") or "").strip()
            repository_root_censored = parse_bool(
                row.get("history_left_censored_at_repository_root") or "false",
                field="history_left_censored_at_repository_root",
            )
        status = item["history_status"]
        item["repository_root_left_censored"] = repository_root_censored
        item["baseline_import_left_censored"] = commit_sha == BASELINE_PREVIEW_IMPORT_COMMIT
        item["left_censored"] = repository_root_censored or item["baseline_import_left_censored"]
        if status == "PUBLISHED_EVIDENCE":
            item["published_datetime"] = parse_iso_datetime(
                item["first_published_committer_time_utc"], field="first_published_committer_time_utc"
            )
        else:
            item["published_datetime"] = None
        result[cve_id] = item
    return result


def validate_snapshots(
    cache_dir: Path,
    manifest_path: Path,
    cohort_ids: set[str],
) -> tuple[dict[str, list[date]], list[dict], list[dict]]:
    fields, rows = read_csv(manifest_path)
    require_columns(
        fields,
        ["decision_date", "candidate_count_raw_epss", "sha256", "bytes", "metadata_header"],
        source=manifest_path.name,
    )
    indexed = require_unique(rows, "decision_date", source=manifest_path.name)
    expected = expected_tuesdays()
    if sorted(indexed) != [value.isoformat() for value in expected]:
        fail("EPSS manifest is not the exact 174-date Tuesday schedule")
    if len(rows) != 174:
        fail(f"EPSS manifest row count {len(rows)} != 174")

    appearances: dict[str, list[date]] = defaultdict(list)
    validation_rows = []
    input_records = []
    for decision_date in expected:
        row = indexed[decision_date.isoformat()]
        path = cache_dir / f"epss_scores-{decision_date.isoformat()}.csv.gz"
        if not path.is_file():
            fail(f"missing EPSS snapshot: {path.name}")
        actual_bytes = path.stat().st_size
        actual_sha = sha256_path(path)
        expected_bytes = int(row["bytes"])
        expected_sha = row["sha256"].strip().lower()
        if actual_bytes != expected_bytes or actual_sha != expected_sha:
            fail(f"EPSS snapshot integrity mismatch: {path.name}")
        seen = set()
        with gzip.open(path, "rt", encoding="utf-8-sig", newline="") as handle:
            metadata = handle.readline().rstrip("\r\n")
            header = handle.readline().rstrip("\r\n")
            columns = header.split(",")
            if not columns or columns[0].strip().lower() != "cve":
                fail(f"unexpected EPSS header in {path.name}: {header!r}")
            count = 0
            for line in handle:
                if not line.strip():
                    continue
                count += 1
                cve_id = line.partition(",")[0].strip()
                if cve_id in cohort_ids:
                    if cve_id in seen:
                        fail(f"duplicate cohort CVE in {path.name}: {cve_id}")
                    seen.add(cve_id)
                    appearances[cve_id].append(decision_date)
        if metadata != row["metadata_header"]:
            fail(f"EPSS metadata header mismatch: {path.name}")
        expected_count = int(row["candidate_count_raw_epss"])
        if count != expected_count:
            fail(f"EPSS row count mismatch in {path.name}: {count} != {expected_count}")
        validation_rows.append(
            {
                "decision_date": decision_date.isoformat(),
                "file": path.name,
                "bytes": actual_bytes,
                "sha256": actual_sha,
                "rows": count,
                "cohort_cves_present": len(seen),
                "metadata_header": metadata,
                "integrity_status": "PASS",
            }
        )
        input_records.append(
            {
                "logical_input": f"EPSS_{decision_date.isoformat()}",
                "file": path.name,
                "bytes": actual_bytes,
                "sha256": actual_sha,
            }
        )
    return appearances, validation_rows, input_records


def load_epss_decision_times(path: Path | None) -> dict[date, dict]:
    """Load contemporaneous timing evidence for the locked snapshot files.

    Exact same-day ordering is admitted only when both the embedded score_date
    and archived HTTP Last-Modified are non-midnight, contemporaneous timestamps.
    Legacy midnight score labels or later re-hosting timestamps remain HOLD.
    """
    if path is None:
        return {}
    fields, rows = read_csv(path)
    require_columns(
        fields,
        ["decision_date", "metadata_header", "last_modified", "sha256", "bytes"],
        source=path.name,
    )
    if len(rows) != 174:
        fail(f"live EPSS acquisition manifest row count {len(rows)} != 174")
    result = {}
    for row in rows:
        decision_date = parse_iso_date(row["decision_date"], field="decision_date")
        match = re.search(r"(?:^|,)score_date:([^,]+)", row["metadata_header"])
        score_dt = None
        if match:
            score_dt = parse_iso_datetime(match.group(1), field="EPSS score_date")
        last_modified = None
        if (row.get("last_modified") or "").strip():
            last_modified = parsedate_to_datetime(row["last_modified"]).astimezone(timezone.utc)
        contemporaneous = bool(
            score_dt
            and last_modified
            and score_dt.date() == decision_date
            and last_modified.date() == decision_date
            and (score_dt.hour, score_dt.minute, score_dt.second) != (0, 0, 0)
        )
        result[decision_date] = {
            "score_datetime_utc": score_dt,
            "last_modified_utc": last_modified,
            "contemporaneous_exact_timing": contemporaneous,
            "requested_url": row.get("requested_url", ""),
            "sha256": row["sha256"].strip().lower(),
            "bytes": int(row["bytes"]),
            "metadata_header": row["metadata_header"],
        }
    if sorted(result) != expected_tuesdays():
        fail("live EPSS acquisition manifest schedule differs from locked 174 Tuesdays")
    return result


def cross_validate_snapshot_manifests(snapshot_rows: list[dict], decision_times: dict[date, dict]) -> None:
    """Fail closed unless the raw/cache and contemporaneous manifests identify identical bytes."""
    if not decision_times:
        fail("live EPSS acquisition manifest is required for same-day evidence")
    raw_by_date = {date.fromisoformat(row["decision_date"]): row for row in snapshot_rows}
    if set(raw_by_date) != set(decision_times):
        fail("raw/cache and live EPSS manifests cover different decision dates")
    for decision_date in sorted(raw_by_date):
        raw = raw_by_date[decision_date]
        live = decision_times[decision_date]
        for field in ("sha256", "bytes", "metadata_header"):
            if raw[field] != live[field]:
                fail(
                    f"raw/cache and live EPSS manifest mismatch for "
                    f"{decision_date.isoformat()} field {field}"
                )


def load_current_metadata(repo: Path, cohort_ids: set[str], expected_head: str) -> dict[str, dict]:
    if expected_head != EXPECTED_HEAD:
        fail(f"requested cvelistV5 HEAD {expected_head} differs from locked HEAD {EXPECTED_HEAD}")
    origin = subprocess.run(
        ["git", "-C", str(repo), "remote", "get-url", "origin"],
        check=True,
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
    ).stdout.strip()
    if origin != EXPECTED_CVELIST_ORIGIN:
        fail(f"cvelistV5 origin {origin!r} != {EXPECTED_CVELIST_ORIGIN!r}")
    dirty = subprocess.run(
        ["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=no"],
        check=True,
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
    ).stdout.strip()
    if dirty:
        fail("cvelistV5 tracked working tree is dirty")
    head = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "HEAD"],
        check=True,
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
    ).stdout.strip()
    if head != expected_head:
        fail(f"cvelistV5 HEAD {head} != pinned {expected_head}")
    result = {}
    for cve_id in sorted(cohort_ids):
        path = repo / cve_path(cve_id)
        if not path.is_file():
            fail(f"current cvelist record missing: {path}")
        raw = path.read_bytes()
        record = json.loads(raw.decode("utf-8-sig"))
        metadata = record.get("cveMetadata") or {}
        cna = ((record.get("containers") or {}).get("cna") or {}).get("providerMetadata") or {}
        if metadata.get("cveId") != cve_id:
            fail(f"current record identity mismatch for {cve_id}")
        result[cve_id] = {
            "state": metadata.get("state"),
            "datePublished": metadata.get("datePublished"),
            "dateUpdated": metadata.get("dateUpdated"),
            "dateReserved": metadata.get("dateReserved"),
            "assignerShortName": metadata.get("assignerShortName"),
            "assignerOrgId": metadata.get("assignerOrgId"),
            "cnaShortName": cna.get("shortName"),
            "cnaOrgId": cna.get("orgId"),
            "content_sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "path": cve_path(cve_id).as_posix(),
        }
    if any(item["state"] != "PUBLISHED" for item in result.values()):
        fail("not every current cohort cvelist record is PUBLISHED")
    return result


def write_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = sorted({key for row in rows for key in row}) if rows else ["empty"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def quantile(values: list[int], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return float(ordered[0])
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[lower])
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def timing_rows(event_rows: list[dict]) -> list[dict]:
    metrics = [
        "git_evidence_to_kev_days",
        "git_evidence_to_first_sampled_epss_days",
        "first_sampled_epss_to_kev_days",
    ]
    strata = {
        "ALL": lambda row: True,
        "A_NO_ADMITTED_PUBLISHED_STATE": lambda row: row["unobservable_partition"] == "A",
        "B_PUBLISHED_STATE_PRESENT_ABSENT_EPSS": lambda row: row["unobservable_partition"] == "B",
        "EPSS_OBSERVABLE": lambda row: row["reconstructed_source_observable"] is True,
        "NON_LEFT_CENSORED": lambda row: row["history_left_censored"] is False,
        "NON_LEFT_CENSORED_EPSS_OBSERVABLE": lambda row: (
            row["history_left_censored"] is False and row["reconstructed_source_observable"] is True
        ),
        "NON_LEFT_CENSORED_A": lambda row: (
            row["history_left_censored"] is False and row["unobservable_partition"] == "A"
        ),
        "HOLD_CLASSIFICATION": lambda row: row["publication_evidence_status"] == "HOLD",
    }
    output = []
    for metric in metrics:
        for stratum, predicate in strata.items():
            values = [int(row[metric]) for row in event_rows if predicate(row) and row[metric] not in {"", None}]
            output.append(
                {
                    "metric": metric,
                    "stratum": stratum,
                    "n": len(values),
                    "min": min(values) if values else "",
                    "p25_linear": quantile(values, 0.25) if values else "",
                    "median": statistics.median(values) if values else "",
                    "p75_linear": quantile(values, 0.75) if values else "",
                    "max": max(values) if values else "",
                    "mean": statistics.fmean(values) if values else "",
                    "note": "Git first-observation lag; root-left-censored rows are not exact publication dates.",
                }
            )
    return output


def add_result(rows: list[dict], section: str, metric: str, value, denominator="", note="") -> None:
    percent = ""
    if isinstance(value, int) and isinstance(denominator, int) and denominator:
        percent = value / denominator
    rows.append(
        {
            "section": section,
            "metric": metric,
            "value": value,
            "denominator": denominator,
            "proportion": percent,
            "note": note,
        }
    )


def strict_snapshot_order(value: datetime | None, timing: dict) -> str:
    if value is None or not timing.get("contemporaneous_exact_timing"):
        return "UNRESOLVED"
    score_dt = timing.get("score_datetime_utc")
    last_modified_dt = timing.get("last_modified_utc")
    if value < score_dt and value < last_modified_dt:
        return "BEFORE"
    if value > score_dt and value > last_modified_dt:
        return "AFTER"
    return "UNRESOLVED"


def resolve_same_day_published_state(
    git_published_dt: datetime,
    immutable_date_published_dt: datetime | None,
    timing: dict,
    *,
    known_date_integrity_issue: bool,
) -> tuple[bool | None, str]:
    """Resolve same-day source-state ordering with two independent clocks.

    A classification is admitted only when the immutable first-blob
    ``datePublished`` is trustworthy and both it and the Git observation fall
    strictly on the same side of the contemporaneous EPSS score and HTTP
    Last-Modified timestamps.  Missing, ambiguous, issue-window, or discordant
    evidence fails closed to HOLD.
    """

    if known_date_integrity_issue:
        return None, "HOLD_KNOWN_DATE_INTEGRITY_ISSUE"
    if immutable_date_published_dt is None:
        return None, "HOLD_MISSING_IMMUTABLE_FIRST_BLOB_DATEPUBLISHED"
    if not timing.get("contemporaneous_exact_timing"):
        return None, "HOLD_NONCONTEMPORANEOUS_EPSS_TIMING"
    git_order = strict_snapshot_order(git_published_dt, timing)
    metadata_order = strict_snapshot_order(immutable_date_published_dt, timing)
    if "UNRESOLVED" in {git_order, metadata_order}:
        return None, "HOLD_AMBIGUOUS_TIMESTAMP_ORDER"
    if git_order != metadata_order:
        return None, "HOLD_GIT_AND_IMMUTABLE_DATEPUBLISHED_DISAGREE"
    if git_order == "BEFORE":
        return True, "PUBLISHED_STATE_PRECEDES_EPSS_BY_GIT_AND_IMMUTABLE_DATEPUBLISHED"
    return False, "PUBLISHED_STATE_FOLLOWS_EPSS_BY_GIT_AND_IMMUTABLE_DATEPUBLISHED"


def assess_immutable_date_published(
    raw_date_published: str,
    git_published_dt: datetime,
    *,
    left_censored: bool,
) -> tuple[datetime | None, str]:
    if left_censored:
        return None, "HOLD_LEFT_CENSORED_FIRST_PUBLISHED_OBSERVATION"
    if not raw_date_published.strip():
        return None, "HOLD_MISSING_IMMUTABLE_FIRST_BLOB_DATEPUBLISHED"
    try:
        parsed = parse_iso_datetime(raw_date_published, field="immutable first-blob datePublished")
    except ValueError:
        return None, "HOLD_INVALID_IMMUTABLE_FIRST_BLOB_DATEPUBLISHED"
    if parsed > git_published_dt:
        return None, "HOLD_IMMUTABLE_DATEPUBLISHED_AFTER_FIRST_GIT_OBSERVATION"
    return parsed, "VERIFIED_TRUSTWORTHY"


def verify_immutable_first_blob_date_published(
    repo: Path,
    cve_id: str,
    history_item: dict,
    git_published_dt: datetime,
) -> tuple[datetime | None, str]:
    """Verify and parse datePublished from the immutable first PUBLISHED blob."""

    commit = (history_item.get("first_published_commit_sha") or "").strip()
    path = (history_item.get("first_published_path") or "").strip()
    expected_sha256 = (history_item.get("first_published_content_sha256") or "").strip().lower()
    if not commit or not path or not expected_sha256:
        return None, "HOLD_INCOMPLETE_IMMUTABLE_BLOB_PROVENANCE"
    reachable = subprocess.run(
        ["git", "-C", str(repo), "merge-base", "--is-ancestor", commit, "HEAD"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if reachable.returncode != 0:
        fail(f"first PUBLISHED commit is not reachable from pinned HEAD for {cve_id}")
    blob = subprocess.run(
        ["git", "-C", str(repo), "show", f"{commit}:{path}"],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout
    actual_sha256 = hashlib.sha256(blob).hexdigest()
    if actual_sha256 != expected_sha256:
        fail(f"immutable first PUBLISHED blob SHA-256 mismatch for {cve_id}")
    record = json.loads(blob.decode("utf-8-sig"))
    metadata = record.get("cveMetadata") or {}
    if metadata.get("cveId") != cve_id or metadata.get("state") != "PUBLISHED":
        fail(f"immutable first PUBLISHED blob identity/state mismatch for {cve_id}")
    raw_date_published = (metadata.get("datePublished") or "").strip()
    ledger_date_published = (
        history_item.get("metadata_date_published_at_first_published") or ""
    ).strip()
    if raw_date_published != ledger_date_published:
        fail(f"immutable datePublished disagrees with history ledger for {cve_id}")
    return assess_immutable_date_published(
        raw_date_published,
        git_published_dt,
        left_censored=bool(history_item.get("left_censored")),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-event-input", type=Path, required=True)
    parser.add_argument("--locked-cohort", type=Path, required=True)
    parser.add_argument("--epss-cache", type=Path, required=True)
    parser.add_argument("--epss-manifest", type=Path, required=True)
    parser.add_argument("--epss-live-manifest", type=Path)
    parser.add_argument("--history-evidence", type=Path, required=True)
    parser.add_argument("--history-provenance", type=Path)
    parser.add_argument("--cvelist-repo", type=Path, required=True)
    parser.add_argument("--expected-head", default=EXPECTED_HEAD)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    baseline_path = args.baseline_event_input.resolve()
    cohort_path = args.locked_cohort.resolve()
    epss_manifest_path = args.epss_manifest.resolve()
    history_path = args.history_evidence.resolve()
    live_manifest_path = args.epss_live_manifest.resolve() if args.epss_live_manifest else None
    require_sha256(baseline_path, EXPECTED_INPUT_SHA256["baseline_event_input"], logical_name="baseline_event_input")
    require_sha256(cohort_path, EXPECTED_INPUT_SHA256["locked_cohort"], logical_name="locked_cohort")
    require_sha256(epss_manifest_path, EXPECTED_INPUT_SHA256["epss_manifest"], logical_name="epss_manifest")
    require_sha256(history_path, EXPECTED_INPUT_SHA256["history_evidence"], logical_name="history_evidence")
    if live_manifest_path is None:
        fail("--epss-live-manifest is required for the locked reconstruction")
    require_sha256(
        live_manifest_path,
        EXPECTED_INPUT_SHA256["epss_live_manifest"],
        logical_name="epss_live_manifest",
    )

    baseline = load_baseline(baseline_path)
    cohort = load_locked_cohort(cohort_path)
    if set(baseline) != set(cohort):
        fail("locked cohort CVE IDs do not exactly match Additional File 2")
    for cve_id in baseline:
        if baseline[cve_id]["kev_date"] != cohort[cve_id]:
            fail(f"KEV date mismatch for {cve_id}")

    history = load_history(history_path)
    if set(history) != set(baseline):
        fail("historical evidence CVE IDs do not exactly match locked cohort")
    current = load_current_metadata(args.cvelist_repo.resolve(), set(baseline), args.expected_head)
    appearances, snapshot_rows, snapshot_inputs = validate_snapshots(
        args.epss_cache.resolve(), epss_manifest_path, set(baseline)
    )
    decision_times = load_epss_decision_times(live_manifest_path)
    cross_validate_snapshot_manifests(snapshot_rows, decision_times)

    schedule = expected_tuesdays()
    event_rows: list[dict] = []
    anomalies: list[dict] = []
    known_issues: list[dict] = []
    for cve_id in sorted(baseline):
        base = baseline[cve_id]
        hist = history[cve_id]
        cur = current[cve_id]
        kev_date = base["kev_date"]
        sampled_dates = sorted(appearances.get(cve_id, []))
        pre_kev_dates = [value for value in sampled_dates if value < kev_date]
        first_sampled = sampled_dates[0] if sampled_dates else None
        first_pre_kev = pre_kev_dates[0] if pre_kev_dates else None
        reconstructed_observable = bool(pre_kev_dates)
        if reconstructed_observable != base["source_observable"]:
            fail(f"raw EPSS replay disagrees with locked source_observable for {cve_id}")

        eligible = [value for value in schedule if value < kev_date]
        pub_dt = hist.get("published_datetime")
        pub_date = pub_dt.date() if pub_dt else None
        published_eligible_dates = [value for value in eligible if pub_date is not None and pub_date < value]

        current_published_date = None
        if cur["datePublished"]:
            current_published_date = parse_iso_date(cur["datePublished"], field="current datePublished")
        immutable_date_published_for_issue = None
        immutable_date_published_raw = (
            hist.get("metadata_date_published_at_first_published", "") or ""
        ).strip()
        if immutable_date_published_raw:
            try:
                immutable_date_published_for_issue = parse_iso_datetime(
                    immutable_date_published_raw,
                    field="immutable first-blob datePublished",
                ).date()
            except ValueError:
                immutable_date_published_for_issue = None
        assigner = (cur["assignerShortName"] or "").strip().lower()
        candidate_issue_dates = {
            value
            for value in (current_published_date, immutable_date_published_for_issue)
            if value is not None
        }
        known_issue_flag = bool(
            assigner == "mitre"
            and any(KNOWN_ISSUE_START <= value <= KNOWN_ISSUE_END for value in candidate_issue_dates)
        )

        same_day_resolution = "NOT_APPLICABLE"
        decision_score_dt = None
        decision_last_modified = None
        immutable_first_blob_dt = None
        immutable_first_blob_trust = "NOT_EVALUATED_NOT_SAME_DAY"
        same_day_git_order = "NOT_APPLICABLE"
        same_day_immutable_order = "NOT_APPLICABLE"
        same_day_concordance = "NOT_APPLICABLE"
        same_day_comparison_dates = {
            value
            for value in (first_pre_kev, base["best_decision_date"])
            if value is not None
        }
        if pub_dt is not None and (
            (not published_eligible_dates and pub_date in eligible)
            or pub_date in same_day_comparison_dates
        ):
            immutable_first_blob_dt, immutable_first_blob_trust = verify_immutable_first_blob_date_published(
                args.cvelist_repo.resolve(), cve_id, hist, pub_dt
            )
        if hist.get("history_status") != "PUBLISHED_EVIDENCE" or pub_date is None:
            publication_stage = "HOLD_UNRESOLVED_HISTORY"
            published_state_precedes_eligible_decision = None
            first_public_decision = None
            hold_reason = "No exact historical PUBLISHED state was reconstructed."
        elif published_eligible_dates:
            publication_stage = "PUBLISHED_STATE_PRECEDES_ELIGIBLE_DECISION"
            published_state_precedes_eligible_decision = True
            first_public_decision = published_eligible_dates[0]
            hold_reason = ""
        elif pub_date in eligible:
            timing = decision_times.get(pub_date, {})
            decision_score_dt = timing.get("score_datetime_utc")
            decision_last_modified = timing.get("last_modified_utc")
            same_day_git_order = strict_snapshot_order(pub_dt, timing)
            same_day_immutable_order = strict_snapshot_order(immutable_first_blob_dt, timing)
            if immutable_first_blob_trust == "VERIFIED_TRUSTWORTHY":
                same_day_order, same_day_resolution = resolve_same_day_published_state(
                    pub_dt,
                    immutable_first_blob_dt,
                    timing,
                    known_date_integrity_issue=known_issue_flag,
                )
            else:
                same_day_order = None
                same_day_resolution = immutable_first_blob_trust
            same_day_concordance = (
                "CONCORDANT"
                if same_day_order is not None
                else "HOLD"
            )
            if same_day_order is True:
                publication_stage = "PUBLISHED_STATE_PRECEDES_SAME_DAY_SNAPSHOT_TIMESTAMP"
                published_state_precedes_eligible_decision = True
                first_public_decision = pub_date
                hold_reason = ""
            elif same_day_order is False:
                publication_stage = "PUBLISHED_STATE_FOLLOWS_SAME_DAY_SNAPSHOT_TIMESTAMP"
                published_state_precedes_eligible_decision = False
                first_public_decision = None
                hold_reason = ""
            else:
                publication_stage = "HOLD_SAME_DAY_DECISION_ORDER"
                published_state_precedes_eligible_decision = None
                first_public_decision = None
                hold_reason = (
                    "First PUBLISHED Git evidence is on the final eligible Tuesday; "
                    "Git time, immutable first-blob datePublished, and the two EPSS timestamps do not provide "
                    "trustworthy concordant intraday order."
                )
        else:
            publication_stage = "NO_ADMITTED_PUBLISHED_STATE_BEFORE_ELIGIBLE_DECISION"
            published_state_precedes_eligible_decision = False
            first_public_decision = None
            hold_reason = ""
        known_issue_resolution = "NOT_APPLICABLE"
        if known_issue_flag:
            exact_known_issue_evidence = bool(
                cve_id == KNOWN_ISSUE_EXPECTED_CVE
                and hist.get("first_published_commit_sha", "") == KNOWN_ISSUE_EXPECTED_COMMIT
                and pub_dt is not None
                and pub_dt.isoformat().replace("+00:00", "Z") == KNOWN_ISSUE_EXPECTED_COMMIT_TIME
                and hist.get("first_published_content_sha256", "") == KNOWN_ISSUE_EXPECTED_CONTENT_SHA256
                and not (hist.get("metadata_date_published_at_first_published", "") or "").strip()
            )
            if exact_known_issue_evidence:
                known_issue_resolution = "RESOLVED_BY_EXACT_HISTORICAL_GIT_AND_ADJACENT_HOURLY_RELEASES"
            else:
                known_issue_resolution = "UNRESOLVED_EVIDENCE_MISMATCH_HOLD"
                publication_stage = "HOLD_KNOWN_ISSUE_UNRESOLVED"
                published_state_precedes_eligible_decision = None
                first_public_decision = None
                hold_reason = "Known MITRE CNA-LR date-issue candidate did not match the pinned immutable evidence tuple."
            known_issues.append(
                {
                    "cve_id": cve_id,
                    "issue": "Official cvelistV5 README warns of approximately 515 MITRE CNA-LR publication/update date discrepancies.",
                    "affected_window": "2024-05-08 through 2024-06-07 inclusive",
                    "current_datePublished": cur["datePublished"],
                    "first_historical_blob_datePublished": hist.get("metadata_date_published_at_first_published", ""),
                    "first_published_commit": hist.get("first_published_commit_sha", ""),
                    "first_published_commit_time_utc": pub_dt.isoformat().replace("+00:00", "Z") if pub_dt else "",
                    "first_published_blob_sha1": hist.get("first_published_git_blob_sha1", ""),
                    "first_published_content_sha256": hist.get("first_published_content_sha256", ""),
                    "prior_hourly_release": (
                        "cve_2024-06-07_0300Z (record absent)" if exact_known_issue_evidence else ""
                    ),
                    "next_hourly_release": (
                        "cve_2024-06-07_0400Z (record present; byte-identical delta entry)"
                        if exact_known_issue_evidence
                        else ""
                    ),
                    "delta_asset_sha256": KNOWN_ISSUE_DELTA_SHA256 if exact_known_issue_evidence else "",
                    "resolution": known_issue_resolution,
                    "partition_effect": (
                        "None; event is EPSS-observable and therefore outside the 274-row A/B/U partition."
                        if exact_known_issue_evidence
                        else "HOLD; no publication classification is admitted."
                    ),
                }
            )

        if not reconstructed_observable:
            if published_state_precedes_eligible_decision is None or (
                known_issue_flag and not known_issue_resolution.startswith("RESOLVED")
            ):
                partition = "U"
            elif published_state_precedes_eligible_decision:
                partition = "B"
            else:
                partition = "A"
        else:
            partition = ""

        def publication_precedes_decision(decision_date: date | None) -> bool | None:
            if decision_date is None or pub_date is None:
                return None
            if pub_date < decision_date:
                return True
            if pub_date > decision_date:
                return False
            timing = decision_times.get(decision_date, {})
            same_day_order, _ = resolve_same_day_published_state(
                pub_dt,
                immutable_first_blob_dt,
                timing,
                known_date_integrity_issue=known_issue_flag,
            )
            return same_day_order

        pub_before_first_epss = publication_precedes_decision(first_pre_kev)
        pub_before_best_capture = publication_precedes_decision(base["best_decision_date"])
        git_to_kev = (kev_date - pub_date).days if pub_date else ""
        git_to_first_sampled = (first_sampled - pub_date).days if pub_date and first_sampled else ""
        first_sampled_to_kev = (kev_date - first_sampled).days if first_sampled else ""

        if known_issue_flag:
            metadata_sensitivity = "HOLD_KNOWN_DATE_ISSUE"
        elif current_published_date is None:
            metadata_sensitivity = "HOLD_MISSING_DATEPUBLISHED"
        elif any(current_published_date < value for value in eligible):
            metadata_sensitivity = "PUBLISHED_DATE_PRECEDES_ELIGIBLE_DECISION"
        elif current_published_date in eligible:
            metadata_sensitivity = "HOLD_SAME_DAY_DECISION_ORDER"
        else:
            metadata_sensitivity = "NO_PUBLISHED_DATE_BEFORE_ELIGIBLE_DECISION"

        row = {
            "cve_id": cve_id,
            "kev_date": kev_date.isoformat(),
            "baseline_source_observable": base["source_observable"],
            "reconstructed_source_observable": reconstructed_observable,
            "top1000_captured": base["top1000_captured"],
            "best_conservative_rank_within_horizon": base["best_rank"] if base["best_rank"] is not None else "",
            "best_decision_date_within_horizon": base["best_decision_date"].isoformat() if base["best_decision_date"] else "",
            "first_sampled_epss_date": first_sampled.isoformat() if first_sampled else "",
            "first_pre_kev_sampled_epss_date": first_pre_kev.isoformat() if first_pre_kev else "",
            "sampled_epss_snapshot_count": len(sampled_dates),
            "eligible_pre_kev_tuesday_count": len(eligible),
            "publication_stage_status": publication_stage,
            "published_state_precedes_any_eligible_decision": (
                published_state_precedes_eligible_decision
                if published_state_precedes_eligible_decision is not None
                else ""
            ),
            "first_eligible_decision_after_published_state": (
                first_public_decision.isoformat() if first_public_decision else ""
            ),
            "unobservable_partition": partition,
            "history_status": hist.get("history_status", ""),
            "history_left_censored": hist.get("left_censored", False),
            "history_left_censor_reason": (
                "2023-03-02_PREVIEW_BASELINE_IMPORT"
                if hist.get("baseline_import_left_censored")
                else ("REPOSITORY_ROOT" if hist.get("repository_root_left_censored") else "")
            ),
            "first_published_git_commit": hist.get("first_published_commit_sha", ""),
            "first_published_git_time_utc": pub_dt.isoformat().replace("+00:00", "Z") if pub_dt else "",
            "first_published_git_date": pub_date.isoformat() if pub_date else "",
            "first_published_git_path": hist.get("first_published_path", ""),
            "first_published_git_blob_sha1": hist.get("first_published_git_blob_sha1", ""),
            "first_published_content_sha256": hist.get("first_published_content_sha256", ""),
            "first_published_parent_shas": hist.get("first_published_parent_shas", ""),
            "prior_history_state": hist.get("prior_history_state", ""),
            "metadata_datePublished_at_first_published_blob": hist.get("metadata_date_published_at_first_published", ""),
            "immutable_first_blob_datePublished_utc": (
                immutable_first_blob_dt.isoformat().replace("+00:00", "Z")
                if immutable_first_blob_dt
                else ""
            ),
            "immutable_first_blob_datePublished_trust_status": immutable_first_blob_trust,
            "current_metadata_datePublished": cur["datePublished"] or "",
            "current_metadata_dateUpdated": cur["dateUpdated"] or "",
            "current_metadata_dateReserved": cur["dateReserved"] or "",
            "current_assignerShortName": cur["assignerShortName"] or "",
            "current_assignerOrgId": cur["assignerOrgId"] or "",
            "current_cnaShortName": cur["cnaShortName"] or "",
            "current_cnaOrgId": cur["cnaOrgId"] or "",
            "current_cvelist_path": cur["path"],
            "current_record_sha256": cur["content_sha256"],
            "known_mitre_date_issue_flag": known_issue_flag,
            "known_issue_resolution": known_issue_resolution,
            "metadata_datePublished_sensitivity_class": metadata_sensitivity,
            "same_day_timing_resolution": same_day_resolution,
            "same_day_git_order_against_epss": same_day_git_order,
            "same_day_immutable_datePublished_order_against_epss": same_day_immutable_order,
            "same_day_three_way_concordance": same_day_concordance,
            "eligible_snapshot_score_datetime_utc": decision_score_dt.isoformat().replace("+00:00", "Z") if decision_score_dt else "",
            "eligible_snapshot_http_last_modified_utc": decision_last_modified.isoformat().replace("+00:00", "Z") if decision_last_modified else "",
            "publication_before_first_pre_kev_epss_decision": pub_before_first_epss if pub_before_first_epss is not None else "",
            "publication_before_best_top1000_decision": pub_before_best_capture if pub_before_best_capture is not None else "",
            "git_evidence_to_kev_days": git_to_kev,
            "git_evidence_to_first_sampled_epss_days": git_to_first_sampled,
            "first_sampled_epss_to_kev_days": first_sampled_to_kev,
            "classification_rule": (
                "Official cvelistV5 PUBLISHED state must precede an eligible decision; same-day admission requires "
                "Git time and verified immutable first-blob datePublished to agree against both EPSS timestamps"
            ),
            "evidence_type": "cvelistV5_GIT_FIRST_PUBLISHED_BLOB",
            "publication_evidence_status": (
                "KEEP" if published_state_precedes_eligible_decision is not None else "HOLD"
            ),
            "hold_reason": hold_reason,
            "metadata_history_discrepancy_flag": bool(
                current_published_date
                and pub_date
                and current_published_date != pub_date
                and not hist.get("left_censored")
            ),
        }
        event_rows.append(row)

        def anomaly(kind: str, severity: str, detail: str) -> None:
            anomalies.append(
                {
                    "cve_id": cve_id,
                    "anomaly_type": kind,
                    "severity": severity,
                    "kev_date": kev_date.isoformat(),
                    "git_published_date": pub_date.isoformat() if pub_date else "",
                    "first_sampled_epss_date": first_sampled.isoformat() if first_sampled else "",
                    "detail": detail,
                    "disposition": "RETAIN_AND_REPORT",
                }
            )

        if reconstructed_observable and published_state_precedes_eligible_decision is not True:
            anomaly(
                "EPSS_OBSERVABLE_NOT_IN_ADMITTED_PUBLISHED_STATE_SET",
                "CRITICAL",
                "Violates event-level set nesting under the conservative date rule.",
            )
        if first_pre_kev and pub_date and first_pre_kev < pub_date:
            anomaly(
                "EPSS_PRECEDES_FIRST_GIT_PUBLISHED_DATE",
                "HIGH",
                "First sampled pre-KEV EPSS presence predates first cvelistV5 PUBLISHED Git evidence.",
            )
        elif first_pre_kev and pub_date and first_pre_kev == pub_date:
            first_order = publication_precedes_decision(first_pre_kev)
            if first_order is None:
                anomaly(
                    "EPSS_SAME_DAY_AS_FIRST_GIT_PUBLISHED_UNRESOLVED",
                    "MEDIUM",
                    "Intraday order is not established by the locked snapshot evidence.",
                )
            else:
                anomaly(
                    "EPSS_SAME_DAY_AS_FIRST_GIT_PUBLISHED_RESOLVED",
                    "INFO",
                    f"Intraday order resolved; publication_precedes_snapshot={str(first_order).lower()}.",
                )
        if base["top1000_captured"] and pub_before_best_capture is not True:
            anomaly(
                "TOP1000_CAPTURE_NOT_PRECEDED_BY_PUBLISHED_STATE_EVIDENCE",
                "HIGH",
                "Best Top-1000 decision is not strictly after first Git PUBLISHED date.",
            )
        if pub_date and pub_date > kev_date:
            anomaly("GIT_PUBLISHED_AFTER_KEV", "HIGH", "First Git PUBLISHED evidence occurs after KEV admission.")
        elif pub_date and pub_date == kev_date:
            anomaly("GIT_PUBLISHED_ON_KEV_DATE", "MEDIUM", "First Git PUBLISHED evidence occurs on KEV admission date.")
        if hist.get("metadata_date_published_at_first_published", "") == "":
            anomaly(
                "FIRST_PUBLISHED_BLOB_LACKS_DATEPUBLISHED",
                "LOW",
                "Historical state is PUBLISHED but the immutable first blob lacks datePublished.",
            )
        if current_published_date and pub_date and current_published_date != pub_date and not hist.get("left_censored"):
            anomaly(
                "CURRENT_METADATA_DATE_DIFFERS_FROM_GIT_EVIDENCE_DATE",
                "LOW",
                "Current mutable datePublished differs from first repository PUBLISHED observation date.",
            )

    counts = Counter(row["unobservable_partition"] for row in event_rows if row["unobservable_partition"])
    if sum(counts.values()) != EXPECTED_UNOBSERVABLE or set(counts) - {"A", "B", "U"}:
        fail(f"invalid A/B/U partition: {dict(counts)}")
    replay_observable = sum(row["reconstructed_source_observable"] for row in event_rows)
    if replay_observable != EXPECTED_OBSERVABLE:
        fail(f"raw replay observable count {replay_observable} != {EXPECTED_OBSERVABLE}")
    first_sample_status = Counter()
    for row in event_rows:
        if row["reconstructed_source_observable"]:
            continue
        if not row["first_sampled_epss_date"]:
            first_sample_status["never"] += 1
        else:
            first_date = date.fromisoformat(row["first_sampled_epss_date"])
            kev = date.fromisoformat(row["kev_date"])
            if first_date == kev:
                first_sample_status["same_day"] += 1
            elif first_date > kev:
                first_sample_status["after"] += 1
            else:
                fail(f"unobservable event has sampled presence before KEV: {row['cve_id']}")
    if first_sample_status != Counter(
        same_day=EXPECTED_SAME_DAY_FIRST_SAMPLE,
        after=EXPECTED_AFTER_FIRST_SAMPLE,
        never=EXPECTED_NEVER_SAMPLED,
    ):
        fail(f"first sampled EPSS diagnostic mismatch: {dict(first_sample_status)}")

    same_day_before_ids = {
        row["cve_id"]
        for row in event_rows
        if row["same_day_timing_resolution"]
        == "PUBLISHED_STATE_PRECEDES_EPSS_BY_GIT_AND_IMMUTABLE_DATEPUBLISHED"
    }
    same_day_after_ids = {
        row["cve_id"]
        for row in event_rows
        if row["same_day_timing_resolution"]
        == "PUBLISHED_STATE_FOLLOWS_EPSS_BY_GIT_AND_IMMUTABLE_DATEPUBLISHED"
    }
    same_day_hold_count = sum(
        row["publication_stage_status"] == "HOLD_SAME_DAY_DECISION_ORDER"
        for row in event_rows
    )
    if same_day_before_ids != EXPECTED_SAME_DAY_PUBLISHED_STATE_BEFORE:
        fail(f"same-day before-snapshot set changed: {sorted(same_day_before_ids)}")
    if same_day_after_ids != EXPECTED_SAME_DAY_PUBLISHED_STATE_AFTER:
        fail(f"same-day after-snapshot set changed: {sorted(same_day_after_ids)}")
    if same_day_hold_count != EXPECTED_SAME_DAY_HOLD:
        fail(f"same-day HOLD count {same_day_hold_count} != {EXPECTED_SAME_DAY_HOLD}")

    published_state_yes = {
        row["cve_id"]
        for row in event_rows
        if row["published_state_precedes_any_eligible_decision"] is True
    }
    published_state_no = {
        row["cve_id"]
        for row in event_rows
        if row["published_state_precedes_any_eligible_decision"] is False
    }
    published_state_hold = {
        row["cve_id"]
        for row in event_rows
        if row["published_state_precedes_any_eligible_decision"] == ""
    }
    epss_yes = {row["cve_id"] for row in event_rows if row["reconstructed_source_observable"] is True}
    top1000_yes = {row["cve_id"] for row in event_rows if row["top1000_captured"] is True}
    epss_not_published_state = sorted(epss_yes - published_state_yes)
    top_not_epss = sorted(top1000_yes - epss_yes)
    set_nested = not epss_not_published_state and not top_not_epss
    sequence_violations = sorted(
        row["cve_id"]
        for row in event_rows
        if row["reconstructed_source_observable"]
        and row["publication_before_first_pre_kev_epss_decision"] is not True
    )
    capture_sequence_violations = sorted(
        row["cve_id"]
        for row in event_rows
        if row["top1000_captured"] and row["publication_before_best_top1000_decision"] is not True
    )
    exact_partition = counts["U"] == 0
    presentation = "NESTED_CHAIN" if set_nested and not sequence_violations and exact_partition else "CROSS_TAB"
    admitted_partition_count = counts["A"] + counts["B"]
    review_disposition = "EVIDENCE_RECONSTRUCTION"

    metadata_sensitivity_counts = Counter(row["metadata_datePublished_sensitivity_class"] for row in event_rows)
    metadata_partition_counts = Counter()
    for row in event_rows:
        if row["reconstructed_source_observable"]:
            continue
        sensitivity = row["metadata_datePublished_sensitivity_class"]
        if sensitivity == "PUBLISHED_DATE_PRECEDES_ELIGIBLE_DECISION":
            metadata_partition_counts["B"] += 1
        elif sensitivity == "NO_PUBLISHED_DATE_BEFORE_ELIGIBLE_DECISION":
            metadata_partition_counts["A"] += 1
        else:
            metadata_partition_counts["U"] += 1
    appearance_order = Counter()
    for row in event_rows:
        if not row["first_sampled_epss_date"] or not row["first_published_git_date"]:
            appearance_order["missing_either_date"] += 1
            continue
        first_epss = date.fromisoformat(row["first_sampled_epss_date"])
        published = date.fromisoformat(row["first_published_git_date"])
        if first_epss < published:
            appearance_order["epss_before_git_published_date"] += 1
        elif first_epss == published:
            appearance_order["epss_on_git_published_date"] += 1
        else:
            appearance_order["epss_after_git_published_date"] += 1

    cross_tab = Counter(
        (
            "HOLD"
            if row["published_state_precedes_any_eligible_decision"] == ""
            else ("YES" if row["published_state_precedes_any_eligible_decision"] else "NO"),
            "YES" if row["reconstructed_source_observable"] else "NO",
        )
        for row in event_rows
    )
    result_rows: list[dict] = []
    add_result(result_rows, "locked", "cohort", EXPECTED_ROWS, EXPECTED_ROWS)
    add_result(result_rows, "locked", "epss_observable", EXPECTED_OBSERVABLE, EXPECTED_ROWS)
    add_result(result_rows, "locked", "epss_unobservable", EXPECTED_UNOBSERVABLE, EXPECTED_ROWS)
    add_result(result_rows, "locked", "top1000_captured", EXPECTED_TOP1000, EXPECTED_ROWS)
    add_result(
        result_rows,
        "publication",
        "published_state_precedes_eligible_decision",
        len(published_state_yes),
        EXPECTED_ROWS,
    )
    add_result(
        result_rows,
        "publication",
        "no_admitted_published_state_before_eligible_decision",
        len(published_state_no),
        EXPECTED_ROWS,
    )
    add_result(result_rows, "publication", "unresolved_hold", len(published_state_hold), EXPECTED_ROWS)
    add_result(
        result_rows,
        "partition",
        "A_no_admitted_published_state_before_eligible_decision",
        counts["A"],
        EXPECTED_UNOBSERVABLE,
    )
    add_result(
        result_rows,
        "partition",
        "B_published_state_present_but_absent_from_epss",
        counts["B"],
        EXPECTED_UNOBSERVABLE,
    )
    add_result(result_rows, "partition", "U_unresolved_hold", counts["U"], EXPECTED_UNOBSERVABLE)
    add_result(result_rows, "partition_bounds", "A_lower", counts["A"], EXPECTED_UNOBSERVABLE, "All U allocated away from A.")
    add_result(result_rows, "partition_bounds", "A_upper", counts["A"] + counts["U"], EXPECTED_UNOBSERVABLE, "All U allocated to A.")
    add_result(result_rows, "partition_bounds", "B_lower", counts["B"], EXPECTED_UNOBSERVABLE, "All U allocated away from B.")
    add_result(result_rows, "partition_bounds", "B_upper", counts["B"] + counts["U"], EXPECTED_UNOBSERVABLE, "All U allocated to B.")
    for (official, epss), value in sorted(cross_tab.items()):
        add_result(result_rows, "cross_tab", f"published_state_{official}_epss_{epss}", value, EXPECTED_ROWS)
    add_result(result_rows, "diagnostic", "unobservable_first_sample_same_kev_day", first_sample_status["same_day"], EXPECTED_UNOBSERVABLE)
    add_result(result_rows, "diagnostic", "unobservable_first_sample_after_kev", first_sample_status["after"], EXPECTED_UNOBSERVABLE)
    add_result(result_rows, "diagnostic", "unobservable_never_sampled", first_sample_status["never"], EXPECTED_UNOBSERVABLE)
    add_result(
        result_rows,
        "nesting",
        "epss_not_in_admitted_published_state_set",
        len(epss_not_published_state),
        EXPECTED_OBSERVABLE,
    )
    add_result(result_rows, "nesting", "top1000_not_in_epss_set", len(top_not_epss), EXPECTED_TOP1000)
    add_result(result_rows, "sequence", "epss_first_presence_not_strictly_after_git_publication", len(sequence_violations), EXPECTED_OBSERVABLE)
    add_result(result_rows, "sequence", "top1000_best_decision_not_strictly_after_git_publication", len(capture_sequence_violations), EXPECTED_TOP1000)
    for key, value in sorted(appearance_order.items()):
        add_result(result_rows, "appearance_order", key, value, EXPECTED_ROWS)
    for key, value in sorted(metadata_sensitivity_counts.items()):
        add_result(result_rows, "metadata_sensitivity", key, value, EXPECTED_ROWS)
    for key in ("A", "B", "U"):
        add_result(
            result_rows,
            "metadata_sensitivity_unobservable_partition",
            key,
            metadata_partition_counts[key],
            EXPECTED_UNOBSERVABLE,
            "Current datePublished sensitivity only; known-issue and same-day cases remain HOLD.",
        )

    summary = {
        "review_disposition": review_disposition,
        "recommended_presentation": presentation,
        "classification_rule": (
            "An official cvelistV5 PUBLISHED state must be observed before an eligible Tuesday decision. "
            "This source-bounded state does not establish availability in vendor advisories or other public sources."
        ),
        "same_day_rule": (
            "KEEP only when first-PUBLISHED Git time and verified immutable first-blob datePublished "
            "concordantly fall strictly before or strictly after both the embedded non-midnight score_date "
            "and archived same-day HTTP Last-Modified; missing, affected, ambiguous, or discordant evidence is HOLD."
        ),
        "pinned_cvelist_head": args.expected_head,
        "counts": {
            "cohort": EXPECTED_ROWS,
            "published_state_precedes_eligible_decision": len(published_state_yes),
            "no_admitted_published_state_before_eligible_decision": len(published_state_no),
            "published_state_hold": len(published_state_hold),
            "epss_observable": len(epss_yes),
            "epss_unobservable": EXPECTED_UNOBSERVABLE,
            "top1000_captured": len(top1000_yes),
            "A_no_admitted_published_state_before_eligible_decision": counts["A"],
            "B_published_state_present_but_absent_from_epss": counts["B"],
            "U_unresolved_hold": counts["U"],
        },
        "partition_bounds": {
            "A_lower": counts["A"],
            "A_upper": counts["A"] + counts["U"],
            "B_lower": counts["B"],
            "B_upper": counts["B"] + counts["U"],
            "denominator": EXPECTED_UNOBSERVABLE,
            "rule": "Deterministic unresolved-allocation extremes; no probabilities assigned.",
        },
        "cross_tab": {
            f"published_state_{key[0]}__epss_{key[1]}": value
            for key, value in sorted(cross_tab.items())
        },
        "nestedness": {
            "event_sets_nested": set_nested,
            "epss_not_in_admitted_published_state_set_count": len(epss_not_published_state),
            "epss_not_in_admitted_published_state_set_ids": epss_not_published_state,
            "top1000_not_in_epss_set_count": len(top_not_epss),
            "top1000_not_in_epss_set_ids": top_not_epss,
            "strict_publication_to_first_epss_sequence_valid": not sequence_violations,
            "sequence_violation_count": len(sequence_violations),
            "sequence_violation_ids": sequence_violations,
            "top1000_sequence_violation_count": len(capture_sequence_violations),
            "top1000_sequence_violation_ids": capture_sequence_violations,
        },
        "known_issue_gate": {
            "candidate_count": len(known_issues),
            "all_candidates_resolved_by_history": all(item["resolution"].startswith("RESOLVED") for item in known_issues),
            "candidate_ids": [item["cve_id"] for item in known_issues],
        },
        "same_day_gate": {
            "concordant_before_count": len(same_day_before_ids),
            "concordant_before_ids": sorted(same_day_before_ids),
            "concordant_after_count": len(same_day_after_ids),
            "concordant_after_ids": sorted(same_day_after_ids),
            "hold_count": same_day_hold_count,
            "admission_requires_verified_immutable_datePublished": True,
        },
        "metadata_datePublished_sensitivity": dict(sorted(metadata_sensitivity_counts.items())),
        "metadata_datePublished_unobservable_partition_sensitivity": {
            key: metadata_partition_counts[key] for key in ("A", "B", "U")
        },
        "first_sampled_epss_vs_git_published_date": dict(sorted(appearance_order.items())),
        "evidence_classification": {
            "resolved_partition_count": admitted_partition_count,
            "resolved_partition_fraction": admitted_partition_count / EXPECTED_UNOBSERVABLE,
            "note": "Descriptive only; no threshold or manuscript decision is derived from this fraction.",
        },
        "locked_reproduction": {
            "raw_epss_snapshot_count": len(snapshot_rows),
            "observable": replay_observable,
            "unobservable": EXPECTED_UNOBSERVABLE,
            "unobservable_first_sample_same_kev_day": first_sample_status["same_day"],
            "unobservable_first_sample_after_kev": first_sample_status["after"],
            "unobservable_never_sampled": first_sample_status["never"],
        },
        "interpretation_boundary": [
            "Git commit time is the first observed official cvelistV5 repository state, not necessarily the real-world disclosure instant.",
            "No admitted PUBLISHED state in cvelistV5 does not imply absence from vendor advisories or any other public source.",
            "The 159 records first observed in the 2023-03-02 preview baseline import are left-censored for exact publication latency but prove only that a PUBLISHED record was present in the admitted source before the study decision.",
            "First EPSS appearance means first appearance in the locked 174 Tuesday snapshots, not first daily EPSS availability.",
            "No exploit-onset, causal, remediation, enterprise-validation, or predictive claim is introduced.",
        ],
    }

    write_csv(output_dir / "CVE_PUBLICATION_EVENT_LEDGER.csv", event_rows)
    write_csv(output_dir / "CVE_PUBLICATION_ANOMALY_LEDGER.csv", anomalies)
    write_csv(output_dir / "CVE_PUBLICATION_KNOWN_ISSUE_LEDGER.csv", known_issues)
    write_csv(output_dir / "CVE_PUBLICATION_RESULTS_TABLES.csv", result_rows)
    write_csv(output_dir / "CVE_PUBLICATION_TIMING_DIAGNOSTICS.csv", timing_rows(event_rows))
    write_csv(output_dir / "EPSS_SNAPSHOT_VALIDATION.csv", snapshot_rows)
    (output_dir / "CVE_PUBLICATION_RECONSTRUCTION_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )

    input_files = [
        ("Additional_File_2_event_input", args.baseline_event_input.resolve()),
        ("locked_749_cohort", args.locked_cohort.resolve()),
        ("EPSS_snapshot_manifest", args.epss_manifest.resolve()),
        ("cvelist_history_evidence", args.history_evidence.resolve()),
    ]
    if args.epss_live_manifest:
        input_files.append(("EPSS_live_acquisition_manifest", args.epss_live_manifest.resolve()))
    if args.history_provenance:
        input_files.append(("cvelist_history_provenance", args.history_provenance.resolve()))
    provenance = {
        "method_version": "CVE_PUBLICATION_RECONSTRUCTION_1.0",
        "python": sys.version,
        "platform": platform.platform(),
        "pinned_cvelist_head": args.expected_head,
        "official_repository": "https://github.com/CVEProject/cvelistV5",
        "locked_cisa_source": "https://raw.githubusercontent.com/cisagov/kev-data/a35cad83b705964915e6d14d9a4977422b884a7c/known_exploited_vulnerabilities.csv",
        "epss_source_pattern": "https://epss.empiricalsecurity.com/epss_scores-YYYY-MM-DD.csv.gz",
        "inputs": [
            {
                "logical_input": name,
                "file": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256_path(path),
            }
            for name, path in input_files
        ]
        + snapshot_inputs,
    }
    (output_dir / "ACQUISITION_AND_PROVENANCE_LOG.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
