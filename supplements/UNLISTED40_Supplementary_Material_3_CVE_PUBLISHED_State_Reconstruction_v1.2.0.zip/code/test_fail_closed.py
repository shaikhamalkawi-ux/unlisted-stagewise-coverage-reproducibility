#!/usr/bin/env python3
"""Adversarial fail-closed tests for the publication reconstruction pipeline."""

from __future__ import annotations

import argparse
import csv
import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import reconstruct_cve_published_state as reconstruction


def expect_failure(name, action, results):
    try:
        action()
    except Exception as exc:  # the exact class is recorded for auditability
        results.append({"test": name, "status": "PASS", "observed_exception": type(exc).__name__, "message": str(exc)})
    else:
        results.append({"test": name, "status": "FAIL", "observed_exception": "", "message": "accepted invalid input"})


def check(name, condition, message, results):
    results.append({"test": name, "status": "PASS" if condition else "FAIL", "message": message})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--epss-cache", type=Path, required=True)
    parser.add_argument("--cvelist-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    results = []
    baseline = args.baseline.resolve()
    manifest = args.manifest.resolve()
    cache = args.epss_cache.resolve()
    repo = args.cvelist_repo.resolve()

    valid = reconstruction.load_baseline(baseline)
    results.append({"test": "valid_locked_baseline", "status": "PASS" if len(valid) == 749 else "FAIL", "message": f"rows={len(valid)}"})
    dates = reconstruction.expected_tuesdays()
    results.append(
        {
            "test": "exact_tuesday_schedule",
            "status": "PASS" if len(dates) == 174 and dates[0].isoformat() == "2023-03-07" and dates[-1].isoformat() == "2026-06-30" else "FAIL",
            "message": f"rows={len(dates)} first={dates[0]} last={dates[-1]}",
        }
    )
    expect_failure("invalid_boolean_rejected", lambda: reconstruction.parse_bool("maybe", field="test"), results)
    expect_failure(
        "wrong_cvelist_head_rejected",
        lambda: reconstruction.load_current_metadata(repo, set(), "0" * 40),
        results,
    )
    expect_failure(
        "cross_manifest_identity_mismatch_rejected",
        lambda: reconstruction.cross_validate_snapshot_manifests(
            [{"decision_date": dates[0].isoformat(), "sha256": "a" * 64, "bytes": 1, "metadata_header": "x"}],
            {dates[0]: {"sha256": "b" * 64, "bytes": 1, "metadata_header": "x"}},
        ),
        results,
    )

    git_dt = datetime(2025, 5, 13, 14, 0, tzinfo=timezone.utc)
    timing = {
        "contemporaneous_exact_timing": True,
        "score_datetime_utc": datetime(2025, 5, 13, 12, 55, tzinfo=timezone.utc),
        "last_modified_utc": datetime(2025, 5, 13, 13, 31, tzinfo=timezone.utc),
    }
    before_git = datetime(2025, 5, 13, 11, 0, tzinfo=timezone.utc)
    before_metadata = datetime(2025, 5, 13, 10, 0, tzinfo=timezone.utc)
    after_metadata = datetime(2025, 5, 13, 13, 45, tzinfo=timezone.utc)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        before_git, before_metadata, timing, known_date_integrity_issue=False
    )
    check("same_day_concordant_before_admitted", resolved is True, reason, results)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt, after_metadata, timing, known_date_integrity_issue=False
    )
    check("same_day_concordant_after_admitted", resolved is False, reason, results)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt, None, timing, known_date_integrity_issue=False
    )
    check("same_day_missing_immutable_date_holds", resolved is None and reason.startswith("HOLD_"), reason, results)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt, after_metadata, timing, known_date_integrity_issue=True
    )
    check("same_day_known_issue_holds", resolved is None and reason == "HOLD_KNOWN_DATE_INTEGRITY_ISSUE", reason, results)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt, before_metadata, timing, known_date_integrity_issue=False
    )
    check("same_day_disagreement_holds", resolved is None and "DISAGREE" in reason, reason, results)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt,
        timing["score_datetime_utc"],
        timing,
        known_date_integrity_issue=False,
    )
    check("same_day_equality_holds", resolved is None and reason == "HOLD_AMBIGUOUS_TIMESTAMP_ORDER", reason, results)
    unresolved_timing = dict(timing, contemporaneous_exact_timing=False)
    resolved, reason = reconstruction.resolve_same_day_published_state(
        git_dt, after_metadata, unresolved_timing, known_date_integrity_issue=False
    )
    check("same_day_noncontemporaneous_timing_holds", resolved is None and reason.startswith("HOLD_"), reason, results)

    parsed, trust = reconstruction.assess_immutable_date_published(
        "2025-05-13T13:45:00Z", git_dt, left_censored=False
    )
    check("immutable_date_trust_valid", parsed is not None and trust == "VERIFIED_TRUSTWORTHY", trust, results)
    parsed, trust = reconstruction.assess_immutable_date_published("", git_dt, left_censored=False)
    check("immutable_date_missing_holds", parsed is None and trust.startswith("HOLD_"), trust, results)
    parsed, trust = reconstruction.assess_immutable_date_published(
        "2025-05-13T13:45:00", git_dt, left_censored=False
    )
    check("immutable_date_timezone_free_holds", parsed is None and trust.startswith("HOLD_"), trust, results)
    parsed, trust = reconstruction.assess_immutable_date_published(
        "2025-05-13T14:01:00Z", git_dt, left_censored=False
    )
    check("immutable_date_after_git_holds", parsed is None and "AFTER_FIRST_GIT" in trust, trust, results)
    parsed, trust = reconstruction.assess_immutable_date_published(
        "2025-05-13T13:45:00Z", git_dt, left_censored=True
    )
    check("immutable_date_left_censored_holds", parsed is None and "LEFT_CENSORED" in trust, trust, results)

    with tempfile.TemporaryDirectory(prefix="cve-reconstruction-negative-") as tmp:
        tmpdir = Path(tmp)
        fields, rows = reconstruction.read_csv(baseline)
        duplicate_path = tmpdir / "duplicate.csv"
        duplicate_rows = [dict(row) for row in rows]
        duplicate_rows[1]["outcome_id"] = duplicate_rows[0]["outcome_id"]
        reconstruction.write_csv(duplicate_path, duplicate_rows, fields)
        expect_failure("duplicate_cve_rejected", lambda: reconstruction.load_baseline(duplicate_path), results)

        manifest_fields, manifest_rows = reconstruction.read_csv(manifest)
        bad_manifest = tmpdir / "bad_manifest.csv"
        changed = [dict(row) for row in manifest_rows]
        changed[0]["sha256"] = "0" * 64
        reconstruction.write_csv(bad_manifest, changed, manifest_fields)
        expect_failure(
            "snapshot_hash_mismatch_rejected",
            lambda: reconstruction.validate_snapshots(cache, bad_manifest, set(valid)),
            results,
        )

        empty_cache = tmpdir / "empty_cache"
        empty_cache.mkdir()
        expect_failure(
            "missing_snapshot_rejected",
            lambda: reconstruction.validate_snapshots(empty_cache, manifest, set(valid)),
            results,
        )

    passed = sum(item["status"] == "PASS" for item in results)
    summary = {"status": "PASS" if passed == len(results) else "FAIL", "passed": passed, "total": len(results), "tests": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if summary["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
