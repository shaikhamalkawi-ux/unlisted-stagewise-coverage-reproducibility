# Production clean-root reconstruction replay

Date: 2026-09-22. Scientific version remains UNLISTED40.

The corrected production code and five small inputs were run once in the production working root and independently in a newly created clean root. No prior reconstruction outputs were copied into the clean output directory. Both runs used Python 3.12 and the same pinned external evidence: cvelistV5 HEAD `4bc05add0932bd642880fc7a46dfb589889217eb`, admitted first-PUBLISHED ledger, and 174 integrity-checked historical EPSS gzip snapshots. The scripts require only the standard library and Git. Exact portable commands are in the corrected supplement README.

Scope: full reconstruction replay, including all 174 snapshot hash/size/header/population checks, cohort consistency, locked counts and immutable-first-blob same-day verification. This production run did not newly acquire or re-extract the complete historical first-state ledger; equivalence of the packaged ledger to accepted R2 was proved by the dedicated transformation test. Accepted R2's earlier historical-extraction evidence remains preserved in the unchanged reference package.

Results:

- Two production runs: eight of eight output files byte-identical.
- Six scientific CSV outputs: byte-identical to accepted R2, not merely equal totals.
- Summary: every scientific field equal to accepted R2. The existing PREAUTHOR code already changed only the administrative `review_disposition` from `CORRECTION_COMPLETE_PENDING_INDEPENDENT_REVIEW` to `EVIDENCE_RECONSTRUCTION`; this correction did not introduce that difference.
- Provenance: regenerated with actual production filenames and input hashes, rather than reusing the accepted package's stale identities.
- Counts preserved: 749 / 475 / 274 / 41; decomposition 251 / 0 / 23; bounds A=251–274, B=0–23.
- Existing fail-closed CLI suite: 20/20 PASS.
- New packaged-input suite: 5/5 hashes, 5/5 altered-byte rejections and 5/5 accepted-source equivalence checks PASS.

`clean_root_rerun_comparison.json` records exact new output hashes. `production_output_mapping.json` maps generated uppercase filenames to the descriptive lowercase delivery names. Output CSV bytes are preserved from the new replay, without any subsequent line-ending normalization. No manuscript, figures, equations, references, GitHub, Zenodo or submission portal was modified by the replay.
